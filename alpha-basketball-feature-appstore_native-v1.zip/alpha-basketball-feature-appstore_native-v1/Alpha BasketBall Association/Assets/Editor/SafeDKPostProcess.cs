﻿#if UNITY_IPHONE
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using UnityEditor.Callbacks;
using UnityEditor.iOS.Xcode;
using System;



public class SafeDKPostProcess {

    [PostProcessBuild]
    public static void OnPostprocessBuild(BuildTarget target, string pathToBuiltProject)
    {
        //Debug.Log("Hello 1: " + WebServiceManager.sharedInstance.IsIntegrationTypeNative());
        if (target == BuildTarget.iOS)
        {
            string projPath = pathToBuiltProject + "/Unity-iPhone.xcodeproj/project.pbxproj";

            PBXProject proj = new PBXProject();
            proj.ReadFromString(File.ReadAllText(projPath));
            string targetDefault = proj.TargetGuidByName("Unity-iPhone");

            var dstLocalPath = "SafeDKSetup-Basketball_iOS.rb";
            var srcPath = Path.Combine(Application.dataPath + "/", dstLocalPath);
            var dstPath = Path.Combine(pathToBuiltProject, dstLocalPath);
            File.Copy(srcPath, dstPath, true);
            proj.AddFileToBuild(targetDefault, proj.AddFile(srcPath, dstLocalPath));



            //var dstLocalVunglePath = "/Pods/VungleSDK-iOS/";
            //var vungleSDKLicensePath = Path.Combine(Application.dataPath + "/", "VungleNativeSDK/LICENSE.md");
            //var vungleSDKReadMeFilePath = Path.Combine(Application.dataPath + "/", "VungleNativeSDK/README.md");
            //var vungleFrameworkPath = Path.Combine(Application.dataPath + "/", "VungleNativeSDK/VungleSDK.framework");


            //Debug.Log("Hello 2: " + vungleSDKLicensePath);
            //Debug.Log("Hello 3: " + vungleSDKReadMeFilePath);
            //Debug.Log("Hello 4: " + vungleFrameworkPath);


            //var dstPathForVungleSDK = Path.Combine(pathToBuiltProject, dstLocalVunglePath);
            //Debug.Log("Hello 5: " + dstPathForVungleSDK);

            //File.Copy(vungleSDKLicensePath, dstPathForVungleSDK, true);
            //File.Copy(vungleSDKReadMeFilePath, dstPathForVungleSDK, true);
            //File.Copy(vungleFrameworkPath, dstPathForVungleSDK, true);

            //proj.AddFileToBuild(targetDefault, proj.AddFile(vungleSDKLicensePath, "LICENSE.md"));
            //proj.AddFileToBuild(targetDefault, proj.AddFile(vungleSDKReadMeFilePath, "README.md"));
            //proj.AddFileToBuild(targetDefault, proj.AddFile(vungleFrameworkPath, "VungleSDK.framework"));
            
            //  proj.AddShellScriptBuildPhase(targetDefault, "Run Script", "/bin/bash -l", "ruby \"$PROJECT_DIR/SafeDKSetup-Basketball_iOS.rb\"");

            File.WriteAllText(projPath, proj.WriteToString());

        }
  

    }
}
#endif