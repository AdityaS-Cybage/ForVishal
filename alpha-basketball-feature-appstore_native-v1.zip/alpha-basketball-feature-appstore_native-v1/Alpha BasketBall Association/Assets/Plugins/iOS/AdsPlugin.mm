//
//  AdsPlugin.m
//  Vungle Sample App
//
//  Created by Swapnil Waghm on 1/31/19.
//  Copyright © 2019 Jordyn Chuhaloff. All rights reserved.
//
#import <VungleSDK/VungleSDK.h>
#import "NewsFeedViewController.h"
#import "iOSWebServiceManager.h"

extern "C" void UnitySendMessage(const char *, const char *, const char *);

@interface AdsPlugin : NSObject<VungleSDKDelegate>
@property (nonatomic, strong) VungleSDK *sdk;
@property (nonatomic, strong) NSString *gameObjectName;
@property (nonatomic, strong) NSString *methodNameAdViewedCompletely;
@property (nonatomic, strong) NSString *methodNameAdAvailable;
@property (nonatomic, strong) NSString *rewardedAdPlacementID;
@property (nonatomic, strong) NSString *interstitialAdPlacementID;
@property (nonatomic, strong) NSString *flexFeedAdPlacementID;
@property (nonatomic, strong) NSString *bannerAdPlacementID;
@property (nonatomic, strong) NSString *receivedID;
@property (nonatomic, strong) NSString *testId;
@property (nonatomic, strong) NSString *userName;
@property (nonatomic, strong) VungleViewInfo *adsInfo;
@property (nonatomic, strong) UIView *bannerView;
@property (nonatomic, strong) NSString *bannerAdSize;
@property (nonatomic, strong) NSString *inFeedAdType;

@property (nonatomic, weak) id<FlexFeedShowProtocol> showDelegate;
@end

@implementation AdsPlugin


- (void)startVungleWithAppID:(const char*)appID
   withRewardedAdplacementID:(const char*)rewardedAdPlacementID
withInterstitialAdPlacementID:(const char*)interstitialAdPlacementID
     withBannerAdPlacementID:(const char*)bannerAdPlacementID
            withFlexFeedAdId:(const char*)flexFeedPlacementId
withGameObjectNameForCallBack:(const char*)gameObjectName
withMethodnameForAdViewCompletion:(const char*)methodNameAdViewedCompletely
withMethodNameForAdAvailability:(const char*)methodNameAdAvailable
              withTestUserId:(const char*)testUserId
                withUsername:(const char*)userName
              withBannerAdSize:(const char*)bannerAdSize
                withInFeedAdType:(const char*)inFeedAdType {
    
    self.sdk = [VungleSDK sharedSDK];
    [self.sdk setDelegate:self];
    [self.sdk setLoggingEnabled:YES];
    
    NSError *error = nil;
    NSString * vungleAppid = [NSString stringWithUTF8String: appID];//@"5c003b9a3933314cf38ff7f3";//@"5c003b9a3933314cf38ff7f3"; //[NSString stringWithUTF8String: appID];
    self.gameObjectName = [NSString stringWithUTF8String:gameObjectName];
    self.methodNameAdViewedCompletely = [NSString stringWithUTF8String: methodNameAdViewedCompletely];
    self.methodNameAdAvailable = [NSString stringWithUTF8String: methodNameAdAvailable];
    self.interstitialAdPlacementID = [NSString stringWithUTF8String: interstitialAdPlacementID];//@"DEFAULT-5045327";//@"LOCAL-8330758";//[NSString stringWithUTF8String: interstitialAdPlacementID];
    self.rewardedAdPlacementID = [NSString stringWithUTF8String: rewardedAdPlacementID];//@"LOCAL_REWARDED-5668925";//@"LOCAL_REWAEDED-5668925";//[NSString stringWithUTF8String: rewardedAdPlacementID];
    self.flexFeedAdPlacementID = [NSString stringWithUTF8String: flexFeedPlacementId];//@"FLEXFEED-5059104";//@"MREC-1627860";//@"FLEXFEED-5059104";//@"MREC-1627860";//[NSString stringWithUTF8String: flexFeedPlacementId];
    self.bannerAdPlacementID =  [NSString stringWithUTF8String: bannerAdPlacementID];//@"BANNER-1541812";//@"BANNER-3400347";//@"BANNER-1541812";//@"FLEXFEED-5059104";//@"FLEXVIEW-9664511";//[NSString stringWithUTF8String: bannerAdPlacementID];
    self.testId = [NSString stringWithUTF8String: testUserId];
    self.userName = [NSString stringWithUTF8String: userName];
    self.bannerAdSize = [NSString stringWithUTF8String: bannerAdSize];
    self.inFeedAdType = [NSString stringWithUTF8String: inFeedAdType];
    
//    static NSString *const VUNGLE_API_ENDPOINT = @"vungle.api_endpoint";
//    static NSString *const kVungleTestAppAPIEndpoint = @"https://apiqa.vungle.com/api/v5";
//    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
//    [defaults setObject:kVungleTestAppAPIEndpoint forKey:VUNGLE_API_ENDPOINT];
//    [defaults synchronize];

    //@"5c003b9a3933314cf38ff7f3"
    if(![self.sdk startWithAppId:vungleAppid error:&error]) {
        NSLog(@"@@@ Error while starting VungleSDK %@", [error localizedDescription]);
        return;
    }
}

-(void)addContainerForBanner{
    if(![self.sdk isInitialized]){
        return;
    }
    
    if([self.userName length] <= 0 ) {
        return;
    }
   
    float width = ([self.bannerAdSize isEqual: @"banner_short"]) ? 300 : 320 ;
    //float width = 320;
    float height = 50;
    float y = (UIScreen.mainScreen.bounds.size.height - height);
    if (@available(iOS 11.0, *)) {
        if( [[[[UIApplication sharedApplication] delegate] window] safeAreaInsets].top > 24 ){
            y = (UIScreen.mainScreen.bounds.size.height - height - 34);
            height = 50;
        }
    }
    CGRect rectForBannerView = CGRectMake((UIScreen.mainScreen.bounds.size.width - width)/2, y, width, height);
    self.bannerView = [[UIView alloc] initWithFrame:rectForBannerView];
    
    [self.bannerView setTag:103];
    self.bannerView.backgroundColor = [UIColor clearColor];
    

    UIImage *placeHolder = [UIImage imageNamed:@"adplaceholder"];
    UIImageView *placeholderImageView = [[UIImageView alloc] initWithImage:placeHolder];
    [placeholderImageView setContentMode:UIViewContentModeScaleAspectFit];
    placeholderImageView.frame = self.bannerView.bounds;
    
    //[self.bannerView addSubview:placeholderImageView];
    
    NSLog(@"@@@ New banner view");
    [UnityGetGLViewController().view addSubview:self.bannerView];
    
    [UnityGetGLViewController().view bringSubviewToFront:self.bannerView];
}


#pragma mark - Autocached Interstitial Ads
-(void)playInterstitial {
    if([self.sdk isAdCachedForPlacementID:self.interstitialAdPlacementID]){
        [iOSWebServiceManager.sharedMySingleton setIsPlayingAd:true];
        NSError *error;
        [self.sdk playAd:UnityGetGLViewController() options:nil placementID:self.interstitialAdPlacementID error:&error];
        if (error) {
            NSLog(@"@@@ Error encountered playing Interstitial ad: %@", error);
            [iOSWebServiceManager.sharedMySingleton setIsPlayingAd:false];
        }
    }else {
        NSLog(@"@@@ Error encountered playing Rewarded ad. Its is not cached");
         [iOSWebServiceManager.sharedMySingleton setIsPlayingAd:false];
    }
    
    
    
}

#pragma mark - Rewarded Ads
-(void)loadRewardedAd {
    NSError* error;
    [self.sdk loadPlacementWithID:self.rewardedAdPlacementID error:&error];
    if (error) {
        NSLog(@"@@@ Error encountered loading Rewarded ad: %@", error);
    }
}

-(void)playRewardedAd {
    
    if([self.sdk isAdCachedForPlacementID:self.rewardedAdPlacementID]){
        [iOSWebServiceManager.sharedMySingleton setIsPlayingAd:true];
        NSError *error;
        NSDictionary *options = @{ VunglePlayAdOptionKeyUser : self.testId,
                                   VunglePlayAdOptionKeyIncentivizedAlertBodyText : @"If the video isn't completed you won't get your reward! Are you sure you want to close early?",
                                   VunglePlayAdOptionKeyIncentivizedAlertCloseButtonText: @"Close",
                                   VunglePlayAdOptionKeyIncentivizedAlertContinueButtonText: @"Keep Watching",
                                   VunglePlayAdOptionKeyIncentivizedAlertTitleText: @"Careful!"
                                   };
        [self.sdk playAd:UnityGetGLViewController() options:options placementID:self.rewardedAdPlacementID error:&error];
        if (error) {
//            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Error" message: [NSString stringWithFormat:@"Ad is available, However %@",error ]  preferredStyle:UIAlertControllerStyleAlert ];
//            UIAlertAction *actionOk = [UIAlertAction actionWithTitle:@"Ok"
//                                                               style:UIAlertActionStyleDefault
//                                                             handler:nil];
//            [alertController addAction:actionOk];
//            [UnityGetGLViewController() presentViewController:alertController animated:YES completion:nil];
            NSLog(@"@@@ Error encountered playing Rewarded ad: %@", error);
            [iOSWebServiceManager.sharedMySingleton setIsPlayingAd:false];
        }
    }else {
         NSLog(@"@@@ Error encountered playing Rewarded ad. Its is not cached");
         [iOSWebServiceManager.sharedMySingleton setIsPlayingAd:false];
    }
    
   
    
}


#pragma mark - Flexfeed Ads
-(void)loadPlacementFlexFeed {
    NSError *error = nil;
    if ([[VungleSDK sharedSDK] loadPlacementWithID:self.flexFeedAdPlacementID error:&error]) {
    } else {
        if (error) {
            NSLog(@"Unable to load placement with reference ID :%@, Error %@", self.flexFeedAdPlacementID, error);
        }
    }
}


-(void)openNewsFeedViewController {
    
    if([iOSWebServiceManager.sharedMySingleton isPlayingAd]){
        return;
    }
    NewsFeedViewController* nfvc = [[NewsFeedViewController alloc] init];
    UINavigationController *navcontroller = [[UINavigationController alloc] initWithRootViewController:nfvc];
    nfvc.placementIDFlexFeed = self.flexFeedAdPlacementID;
    nfvc.inFeedAdType = self.inFeedAdType;
    iOSWebServiceManager.sharedMySingleton.delegate = nfvc;
    self.showDelegate = nfvc;
    [UnityGetGLViewController() presentViewController:navcontroller animated:YES completion:nil];
    
}

#pragma mark - Banner Ads
-(void)loadBannerAd {
    
    NSError* error;
    VungleAdSize adSize = ([self.bannerAdSize  isEqual: @"banner"])?VungleAdSizeBanner: VungleAdSizeBannerShort;
    [self.sdk loadPlacementWithID:self.bannerAdPlacementID withSize:adSize error:nil];
    if (error) {
        NSLog(@"@@@ Error encountered loading Banner ad: %@", error);
    }
}

-(void)showBannerAd {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSError *error;
        [[VungleSDK sharedSDK] addAdViewToView:self.bannerView withOptions:nil placementID:self.bannerAdPlacementID error:&error];
        NSLog(@"@@@ Show Banner called ");
        if (error)
        {
            NSLog(@"Error encountered while playing Banner ad: %@", error);
            // [self loadBannerAd];
        }
    });
}


#pragma mark - VungleSDKDelegate Methods
- (void)vungleAdPlayabilityUpdate:(BOOL)isAdPlayable placementID:(NSString *)placementID error:(NSError *)error {
    if(![self.sdk isInitialized]) {
        return;
    }
    
    if (isAdPlayable) {
        
        if ([placementID isEqualToString:self.rewardedAdPlacementID]) {
            NSLog(@"@@@ Delegate Callback: vungleAdPlayabilityUpdate: Ad is available for Placement ID: %@", placementID);
            if(!iOSWebServiceManager.sharedMySingleton.isPlayingAd){
                NSLog(@"@@@ enable button Send message to Unity ");
                UnitySendMessage([self.gameObjectName UTF8String], [self.methodNameAdAvailable UTF8String], [@"1" UTF8String]);
            } else {
                [self performSelector:@selector(loadRewardedAd) withObject:nil afterDelay:15];
            }
        } else if([placementID isEqualToString:self.bannerAdPlacementID]){
            if([self.userName length] > 0 ) {
                [self showBannerAd];
            }
        }else if([placementID isEqualToString:self.flexFeedAdPlacementID]){
            NSLog(@"@@@ Delegate Callback: vungleAdPlayabilityUpdate: Ad is available for Placement ID: %@", placementID);
             [self.showDelegate refreshAdCell];
        }
    }
    else {
        if ([placementID isEqualToString:self.rewardedAdPlacementID]) {
            NSLog(@"@@@ Delegate Callback: vungleAdPlayabilityUpdate: Ad is NOT available for Placement ID: %@", placementID);
            
            NSLog(@"@@@ Disable button Send message to Unity to ");
            UnitySendMessage([self.gameObjectName UTF8String], [self.methodNameAdAvailable UTF8String], [@"0" UTF8String]);
            [self performSelector:@selector(loadRewardedAd) withObject:nil afterDelay:30];
        }else if([placementID isEqualToString:self.flexFeedAdPlacementID]){
            NSLog(@"@@@ Delegate Callback: vungleAdPlayabilityUpdate: Ad is NOT available for Placement ID: %@", placementID);
        }
    }
}

- (void)vungleWillShowAdForPlacementID:(nullable NSString *)placementID {
    NSLog(@"@@@ Delegate Callback: vungleWillShowAdForPlacementID %@",placementID);
    if([placementID isEqualToString:self.interstitialAdPlacementID]){
        [self loadRewardedAd];
    }else if([placementID isEqualToString:self.flexFeedAdPlacementID]){
        iOSWebServiceManager.sharedMySingleton.isPlayingFeedAd = true;
    }
}

- (void)vungleWillCloseAdWithViewInfo:(VungleViewInfo *)info placementID:(NSString *)placementID {
    NSLog(@"@@@ Delegate Callback: vungleWillCloseAdWithViewInfo %@",placementID);
    self.receivedID = placementID;
    self.adsInfo = info;
    if ([self.receivedID isEqualToString:self.rewardedAdPlacementID] ||[self.receivedID isEqualToString:self.interstitialAdPlacementID]){
        
        if ([self.receivedID isEqualToString:self.rewardedAdPlacementID]) {
            if (self.adsInfo.completedView.intValue == 1){
                UnitySendMessage([self.gameObjectName UTF8String], [self.methodNameAdViewedCompletely UTF8String], [@"1" UTF8String]);
            } else {
                UnitySendMessage([self.gameObjectName UTF8String], [self.methodNameAdViewedCompletely UTF8String], [@"0" UTF8String]);
            }}
        [iOSWebServiceManager.sharedMySingleton setIsPlayingAd:false];
    } else if ([self.receivedID isEqualToString:self.flexFeedAdPlacementID]){
        NSLog(@"@@@ Flex feed ad closed");
        iOSWebServiceManager.sharedMySingleton.isPlayingFeedAd = false;
        [self loadPlacementFlexFeed];
    }
}


- (void)vungleSDKDidInitialize {
    NSLog(@"@@@ Delegate Callback: vungleSDKDidInitialize - SDK initialized SUCCESSFULLY");
    [self loadRewardedAd];
    [self loadPlacementFlexFeed];
    if(self.bannerView == nil){
         [self addContainerForBanner];
    }
   
    [self loadBannerAd];
}


@end
#pragma mark - CPP methods called from Unity
static AdsPlugin *adsPlugin = nil;

extern "C"
{
    void _initializeSDK(const char* appID,
                        const char* rewardedPlacementID,
                        const char* interstitialPlacementID ,
                        const char* bannerAdPlacementID,
                        const char* flexFeedAdId ,
                        const char* gameObjectName,
                        const char* methodNameAdViewedCompletely,
                        const char* methodNameAdAvailable,
                        const char* testId,
                        const char* userName,
                        const char* bannerAdSize,
                        const char* inFeedAdType) {
        if (adsPlugin == nil)
            adsPlugin = [[AdsPlugin alloc] init];
        [adsPlugin startVungleWithAppID:appID withRewardedAdplacementID:rewardedPlacementID
          withInterstitialAdPlacementID:interstitialPlacementID
                withBannerAdPlacementID:bannerAdPlacementID
                       withFlexFeedAdId:flexFeedAdId
          withGameObjectNameForCallBack:gameObjectName
      withMethodnameForAdViewCompletion:methodNameAdViewedCompletely
        withMethodNameForAdAvailability:methodNameAdAvailable
                         withTestUserId:testId
                           withUsername:userName
                         withBannerAdSize:bannerAdSize
                        withInFeedAdType:inFeedAdType ];
    }
    
    void _playInterstitial() {
        if(adsPlugin != nil){
            [adsPlugin playInterstitial];
        }
    }
    
    void _loadRewardedAd(){
        if(adsPlugin != nil){
            [adsPlugin loadRewardedAd];
        }
    }
    
    void _playRewardedAd(){
        if(adsPlugin != nil){
            [adsPlugin playRewardedAd];
        }
    }
    
    void _openNewsFeedViewController(){
        if(adsPlugin != nil){
            [adsPlugin openNewsFeedViewController];
        }
    }
    void _addBannerView(const char* userName){
        if(adsPlugin != nil){
            NSString* strusername =  [NSString stringWithUTF8String:userName];
            if ([strusername length] > 0){
                [adsPlugin setUserName:strusername];
                [adsPlugin addContainerForBanner];
                [adsPlugin showBannerAd];
            }
            
        }
    }
}

