//
//  NewsFeedTableViewCell.h
//  
//
//  Created by Swapnil Waghm on 8/16/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NewsFeedTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblNewsTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblNewsDate;
@property (weak, nonatomic) IBOutlet UIImageView *imgNewsImage;
@property (weak, nonatomic) IBOutlet UILabel *lblNoDataAvailable;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@end

NS_ASSUME_NONNULL_END
