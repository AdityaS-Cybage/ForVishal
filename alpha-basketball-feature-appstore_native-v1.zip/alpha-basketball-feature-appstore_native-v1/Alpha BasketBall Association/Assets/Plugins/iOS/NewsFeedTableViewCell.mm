//
//  NewsFeedTableViewCell.m
//  
//
//  Created by Swapnil Waghm on 8/16/19.
//

#import "NewsFeedTableViewCell.h"

@implementation NewsFeedTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

-(void)prepareForReuse{
    self.imgNewsImage.image = nil;
}
@end
