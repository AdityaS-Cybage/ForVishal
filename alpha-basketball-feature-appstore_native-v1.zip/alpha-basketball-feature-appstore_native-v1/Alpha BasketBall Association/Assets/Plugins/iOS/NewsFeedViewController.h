//
//  NewsFeedViewController.h
//  Unity-iPhone
//
//  Created by Swapnil Waghm on 2/4/19.
//

#import <UIKit/UIKit.h>
#import <VungleSDK/VungleSDK.h>
#import "iOSWebServiceManager.h"

@interface NewsFeedViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,ImageDownloaderProtocol,FlexFeedShowProtocol>
@property (strong,nonatomic) UITableView *feedTableView;
@property (strong, nonatomic) NSString *placementIDFlexFeed;
@property (strong, nonatomic) NSString *inFeedAdType;
@property (strong, nonatomic) NSMutableArray *marrFeedObjcts;
@end
