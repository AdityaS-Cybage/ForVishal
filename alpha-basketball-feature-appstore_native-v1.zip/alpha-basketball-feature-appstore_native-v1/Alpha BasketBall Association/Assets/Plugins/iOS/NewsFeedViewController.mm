//
//  NewsFeedViewController.m
//  Unity-iPhone
//
//  Created by Swapnil Waghm on 2/4/19.
//

#import "NewsFeedViewController.h"
#import "NewsFeedTableViewCell.h"
#import "WebView.h"

@interface NewsFeedViewController ()

@end

@implementation NewsFeedViewController

int newsFeedHeight;
int newsFeedWidth;
#pragma mark - Lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    newsFeedHeight = ([self.inFeedAdType  isEqual: @"infeed"]) ? 200 : 250;
    newsFeedWidth = ([self.inFeedAdType  isEqual: @"infeed"]) ? [UIScreen mainScreen].bounds.size.width : 300;
    self.marrFeedObjcts = [[NSMutableArray alloc] init];
    [self UISetup];
    [self getJSONData];
    if([[VungleSDK sharedSDK] isInitialized] && [[VungleSDK sharedSDK] isAdCachedForPlacementID:self.placementIDFlexFeed] == false){
        [self loadFlexFeed];
    }
    
}


/**
 This function will do all UI related setup for News Feed View Controller.
 */
-(void)UISetup{
    
    self.navigationItem.title = @"News Feed";
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    
    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Back" style: UIBarButtonItemStylePlain target:self action: @selector(dismissModal)];
    
    self.navigationController.navigationBar.topItem.title = @"News Feed";
    [self.navigationController.navigationBar.topItem setLeftBarButtonItem: cancelButton];
    self.view.backgroundColor = UIColor.brownColor;
    self.feedTableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain];
    self.feedTableView.dataSource = self;
    self.feedTableView.delegate = self;
    UINib *nib = [UINib nibWithNibName:@"NewsFeedTableViewCell" bundle:nil];
    [self.feedTableView registerNib:nib forCellReuseIdentifier:@"NewsFeedTableViewCell"];
    [self.view addSubview:self.feedTableView];
}

/**
 This function will fetch json data from file stored in Documents directory
 */
-(void)getJSONData
{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains (NSDocumentDirectory, NSUserDomainMask,
                                                          YES);
    NSString *documentsPath = [paths objectAtIndex:0];
    NSString *plistPath = [documentsPath stringByAppendingPathComponent:@"/NewsFeedData/NewsFeedData.plist"];
    NSArray *feedArray = [NSArray arrayWithContentsOfFile:plistPath];
    [self.marrFeedObjcts addObjectsFromArray:feedArray];
    
    if ([self.marrFeedObjcts count] > 2){
        
        CGRect flexFeedViewFrame = CGRectMake(0, 0, newsFeedWidth, newsFeedHeight);
        UIView * flexFeedAdView = [[UIView alloc] initWithFrame:flexFeedViewFrame];
        flexFeedAdView.backgroundColor = [UIColor clearColor];
        
        UIImage *placeHolder = [UIImage imageNamed:@"adplaceholder"];
        UIImageView *placeholderImageView = [[UIImageView alloc] initWithImage:placeHolder];
        [placeholderImageView setContentMode:UIViewContentModeScaleAspectFit];
        placeholderImageView.frame = flexFeedViewFrame;
        [flexFeedAdView addSubview:placeholderImageView];
        
        [self.marrFeedObjcts insertObject:flexFeedAdView atIndex:2];
    }
    
    [self.feedTableView reloadData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 This function will get called on click of Back button
 */
-(void) dismissModal
{
    NSLog(@"Closing modal");
    [[VungleSDK sharedSDK]finishedDisplayingAd];
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - TableView Data Source

/**
 This function will render each cell of table view.
 For Ad View cell it will call ads api.
 For other cells it would show feed data
 
 @param tableView feed tableview
 @param indexPath current index path
 @return Completely rendered cell
 */
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (self.marrFeedObjcts.count > 0){
        if ([[self.marrFeedObjcts objectAtIndex:indexPath.row] isKindOfClass:[NSDictionary class] ])
        {
            NewsFeedTableViewCell * cellFeed = (NewsFeedTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"NewsFeedTableViewCell"];
            NSDictionary *dictFeed = [self.marrFeedObjcts objectAtIndex:indexPath.row];
            NSString *title = [NSString stringWithFormat:@"%@",[dictFeed valueForKey:@"newsTitle"]];
            cellFeed.lblNewsTitle.text = title;
            cellFeed.lblNewsDate.text = [NSString stringWithFormat:@"%@",[dictFeed valueForKey:@"newsDate"]];;
            cellFeed.imgNewsImage.layer.cornerRadius = 5;//cellFeed.imgNewsImage.frame.size.height /2;
            cellFeed.imgNewsImage.layer.masksToBounds = YES;
            cellFeed.imgNewsImage.layer.borderWidth = 0;
            cellFeed.tag = indexPath.row;
            cellFeed.imgNewsImage.image = nil;
            NSString*imagePath = [NSString stringWithFormat:@"%@/%@/%@",[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0],@"NewsFeedData",[dictFeed valueForKey:@"id"]];
            UIImage *imgData = [UIImage imageWithContentsOfFile:imagePath];
            if(imgData !=  nil){
                [cellFeed.activityIndicator stopAnimating];
                [cellFeed.activityIndicator setHidden:true];
                cellFeed.imgNewsImage.image = [UIImage imageWithContentsOfFile:imagePath];
                
            } else {
                [cellFeed.activityIndicator setHidden:false];
                [cellFeed.activityIndicator startAnimating];
                
            }
            
            return cellFeed;
        } else if ([[self.marrFeedObjcts objectAtIndex:indexPath.row] isKindOfClass:[UIView class] ])
        {
            UITableViewCell *feedAdCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"FlexFeedAd"];
            [feedAdCell setSelectionStyle:UITableViewCellSelectionStyleNone];
            UIView *feedView = [self.marrFeedObjcts objectAtIndex:indexPath.row];
            [feedAdCell setPreservesSuperviewLayoutMargins:false];
            [feedAdCell setSeparatorInset:UIEdgeInsetsZero];
            [feedAdCell setLayoutMargins:UIEdgeInsetsZero];
            NSError *error;
            [feedAdCell.contentView addSubview:feedView];
            feedView.center = CGPointMake([UIScreen mainScreen].bounds.size.width/2, feedView.center.y);
            if([[VungleSDK sharedSDK] isInitialized]){
                [[VungleSDK sharedSDK] addAdViewToView:feedView withOptions:nil placementID:self.placementIDFlexFeed error:&error];
                if (error)
                {
                    NSLog(@"Error encountered while playing Flexfeed ad: %@", error);
                    iOSWebServiceManager.sharedMySingleton.isPlayingFeedAd = false;
                    [self loadFlexFeed];
                }
            }
            
            return feedAdCell;
        } else {
            return [[UITableViewCell alloc] init];
            NSLog(@"Unknown cell index Neither dictionary nor view %ld", (long)indexPath.row);
        }
        
    } else {
        NewsFeedTableViewCell * cellFeed = (NewsFeedTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"NewsFeedTableViewCell"];
        
        cellFeed.lblNewsTitle.text = @"";
        cellFeed.imgNewsImage.image = nil;
        cellFeed.lblNewsDate.text = @"";
        cellFeed.lblNoDataAvailable.hidden = false;
        [cellFeed.activityIndicator stopAnimating];
        [cellFeed.activityIndicator setHidden:true];
        return cellFeed;
    }
}

/**
 This function will define number of rows in given section
 */
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if ([self.marrFeedObjcts count] > 0){
        return [self.marrFeedObjcts count];
    }
    return 1;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

/**
 This function will define height for each cell.
 For feed cells it would be as defined in XIB.
 For Ads cell it would be 200
 
 */
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([self.marrFeedObjcts count] > 0){
        if ([[self.marrFeedObjcts objectAtIndex:indexPath.row] isKindOfClass:[NSDictionary class] ]){
            return 90;
        }
        else {
            return  newsFeedHeight;
        }
    }
    return UIScreen.mainScreen.bounds.size.height;
}

#pragma mark - TableView delegate

/**
 Open In App webview on click of this Feed cell
 */
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:false];
    if ([self.marrFeedObjcts count] > 0){
        if ([[self.marrFeedObjcts objectAtIndex:indexPath.row] isKindOfClass:[NSDictionary class] ]){
            NSString *newsLink = [(NSDictionary *)[self.marrFeedObjcts objectAtIndex:indexPath.row] valueForKey:@"newsLink"];
            [ [[NativeWebView alloc] init] openWebViewControllerForUrl:[newsLink UTF8String] overViewController:self withTitle:[@"News" UTF8String]];
        }
    }
}

#pragma mark - ImageDownloaderProtocol Implementation

/**
 This function will render imageview of cell with downloaded image
 @param imageName  : Name of the image
 */
-(void)downloadComepletedforImagenamed:(NSString *)imageName{
    NSUInteger index = 0;
    for (id obj in self.marrFeedObjcts){
        if([obj isKindOfClass:[NSDictionary class]]){
            NSDictionary *dict = (NSDictionary *)obj;
            if([[dict valueForKey:@"id"] isEqualToString:imageName]){
                NSLog(@"object is %@", dict);
                index = [self.marrFeedObjcts indexOfObject:obj];
            }
        }
    }
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
    NSArray *indexPaths = [[NSArray alloc] initWithObjects:indexPath, nil];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.feedTableView beginUpdates];
        [self.feedTableView reloadRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationNone];
        [self.feedTableView endUpdates];
        
    });
}
#pragma mark - Local methods to avoid Empty View scenarion

/**
 This function will delete any empty Ad view
 */
-(void)removeAdView{
    NSLog(@"@@@ Inside removeAdView");
    if ([[self.marrFeedObjcts objectAtIndex:2] isKindOfClass:[UIView class]]){
        [self.marrFeedObjcts removeObjectAtIndex:2];
        [self.feedTableView reloadData];
        NSLog(@"@@@ Ad view removed, Loading flexfeed again");
        [self loadFlexFeed];
    }
    
}
#pragma mark - FlexFeedShowProtocol Implementation

/**
 This function will load flexfeed cell
 */
-(void)loadFlexFeed {
    NSError *error = nil;
    if ([[VungleSDK sharedSDK] loadPlacementWithID:self.placementIDFlexFeed error:&error]) {
    } else {
        if (error) {
            NSLog(@"Unable to load placement with reference ID :%@, Error %@", self.placementIDFlexFeed, error);
        }
    }
}

/**
 This function will show flex feed cell
 */
-(void)showFlexFeed {
    NSLog(@"@@@ Inside showFlexFeed");
    if ([self.marrFeedObjcts count] > 2){
        if ([[self.marrFeedObjcts objectAtIndex:2] isKindOfClass:[UIView class]] ){
            if(iOSWebServiceManager.sharedMySingleton.isPlayingFeedAd == false){
                [self performSelector:@selector(refreshAdCell) withObject:nil afterDelay:1];
            }
            return;
        }
        CGRect flexFeedViewFrame = CGRectMake(0, 0, newsFeedWidth, newsFeedHeight);
        UIView * flexFeedAdView = [[UIView alloc] initWithFrame:flexFeedViewFrame];
        flexFeedAdView.backgroundColor = [UIColor clearColor];
        [self.marrFeedObjcts insertObject:flexFeedAdView atIndex:2];
        [self.feedTableView reloadData];
    }
}

/**
 This function will refresh ads cell
 */
-(void)refreshAdCell {
    NSLog(@"@@@ Inside refreshAdCell");
    if ([self.marrFeedObjcts count] > 2){
        if ([[self.marrFeedObjcts objectAtIndex:2] isKindOfClass:[UIView class]] && iOSWebServiceManager.sharedMySingleton.isPlayingFeedAd == false){
            iOSWebServiceManager.sharedMySingleton.isPlayingFeedAd = true;
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:2 inSection:0];
            NSArray *indexPaths = [[NSArray alloc] initWithObjects:indexPath, nil];
            [self.feedTableView reloadRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationNone];
            NSLog(@"@@@ Reloading 2nd cell");
        }
    }
}

@end

