#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

extern "C" UIViewController *UnityGetGLViewController();
extern void UnitySendMessage(const char *, const char *, const char *);

@interface NativeWebView : UINavigationController
	// To use WKWebView you need to add WkWebView.framekwork via Xcode
@property(strong, nonatomic) WKWebView *webView;
@property(strong, nonatomic) NSString *gameObject;
@property(strong, nonatomic) NSString *method;

//-(void) setup:(const char*)gameObjectName method:(const char*)methodName;
-(void) openWebViewControllerForUrl:(const char*)urlString overViewController:(UIViewController *)viewControllerObj withTitle:(const char*)title ;

@end


