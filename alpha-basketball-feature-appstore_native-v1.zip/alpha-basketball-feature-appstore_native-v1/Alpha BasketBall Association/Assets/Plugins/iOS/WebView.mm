#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import "WebView.h"
#import "iOSWebServiceManager.h"
extern "C" UIViewController *UnityGetGLViewController();
extern void UnitySendMessage(const char *, const char *, const char *);

@implementation NativeWebView

-(id)init
{
    self.webView = [[WKWebView alloc] init];
    
    UIViewController *webViewController = [[UIViewController alloc] init];
    webViewController.view = self.webView;
    
    self = [super initWithRootViewController: webViewController];
    self.navigationBar.barStyle = UIBarStyleDefault;
    
    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Back" style: UIBarButtonItemStylePlain target:self action: @selector(dismissModal)];
    
    [self.navigationBar.topItem setLeftBarButtonItem: cancelButton];
    return self;
}

/**
 Gives callback to Unity

 @param gameObjectName Name of game object in Unity
 @param methodName name of Method to be called in Unity
 */
-(void) setupCallBack:(const char*)gameObjectName method:(const char*)methodName
{
    self.gameObject = [NSString stringWithUTF8String:gameObjectName];
    self.method = [NSString stringWithUTF8String:methodName];
}

/**
 This function will open InApp Webview controller

 @param urlString url to be loaded in webview
 @param viewControllerObj viewcontroller instance
 @param title title to be shown on view controllers navigation bar
 */
-(void) openWebViewControllerForUrl:(const char*)urlString overViewController:(UIViewController *)viewControllerObj withTitle:(const char*)title
{    if([iOSWebServiceManager.sharedMySingleton isPlayingAd]){
    return;
}
    self.navigationBar.topItem.title = [NSString stringWithUTF8String:title] ;
    NSURL *url = [[NSURL alloc] initWithString: [NSString stringWithUTF8String: urlString]];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [self.webView loadRequest:request];
    
    if (viewControllerObj != nil){
        [viewControllerObj presentViewController:self animated:YES completion:nil];
        
    } else {
        [UnityGetGLViewController() presentViewController:self animated:YES completion:nil];
        
    }
}

/**
 This function is called when back button is clicked
 */
-(void) dismissModal
{
    NSURL *url = [[NSURL alloc] initWithString: [NSString stringWithUTF8String: "about:blank"]];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [self.webView loadRequest:request];
    
    UnitySendMessage([self.gameObject UTF8String], [self.method UTF8String], "Calling back from iOS device");
    [self dismissViewControllerAnimated:true completion:nil];
}

@end

static NativeWebView *nativeWebViewPlugin = nil;

extern "C"
{
    void _nativeLog() {
        NSLog(@"Log called from Unity");
    }
    
    void _setupCallBack(const char* gameObjectName, const char* methodName) {
        if (nativeWebViewPlugin == nil)
            nativeWebViewPlugin = [[NativeWebView alloc] init];
        
        [nativeWebViewPlugin setupCallBack:gameObjectName method:methodName];
    }
    
    void _openURL(const char* url) {
        [nativeWebViewPlugin openWebViewControllerForUrl:url overViewController:nil withTitle:[@"Leaderboard" UTF8String]];
    }
}
