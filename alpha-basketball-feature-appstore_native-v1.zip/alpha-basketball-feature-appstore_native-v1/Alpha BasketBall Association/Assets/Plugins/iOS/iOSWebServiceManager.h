//
//  iOSWebServiceManager.h
//  Unity-iPhone
//
//  Created by Swapnil Waghm on 8/20/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@protocol ImageDownloaderProtocol
-(void) downloadComepletedforImagenamed:(NSString *)imageName;
@end

@protocol FlexFeedShowProtocol
-(void)showFlexFeed;
-(void)loadFlexFeed;
-(void)refreshAdCell;
@end

@interface iOSWebServiceManager : NSObject
@property (nonatomic, strong) NSOperationQueue *operationQueue;
@property (nonatomic, weak) id<ImageDownloaderProtocol> delegate;
-(void)_fetchAndSaveNewsFeedDataFromUrl:(const char*)newsFeedUrl;
+(iOSWebServiceManager *)sharedMySingleton;
@property(nonatomic) BOOL isPlayingAd;
@property(nonatomic) BOOL isPlayingFeedAd;
@end

NS_ASSUME_NONNULL_END
