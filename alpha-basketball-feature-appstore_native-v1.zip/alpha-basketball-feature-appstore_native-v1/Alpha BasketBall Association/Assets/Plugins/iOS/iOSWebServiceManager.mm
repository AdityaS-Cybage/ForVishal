//
//  iOSWebServiceManager.m
//  Unity-iPhone
//
//  Created by Swapnil Waghm on 8/20/19.
//

#import "iOSWebServiceManager.h"

@implementation iOSWebServiceManager

static iOSWebServiceManager *_sharedMySingleton = nil;

/**
 Creating shared singleton instance

 @return instance
 */
+(iOSWebServiceManager *)sharedMySingleton {
    @synchronized([iOSWebServiceManager class]) {
        if (!_sharedMySingleton)
            _sharedMySingleton = [[self alloc] init];
        return _sharedMySingleton;
    }
    return nil;
}

-(BOOL) isPlayingAd {
    return _isPlayingAd ? _isPlayingAd : false;
}
-(BOOL) isPlayingFeedAd {
    return _isPlayingFeedAd ? _isPlayingFeedAd : false;
}


/**
Fetch news feed data from Server
 @param newsFeedUrl newsfeed url
 */
-(void)_fetchAndSaveNewsFeedDataFromUrl:(const char*)newsFeedUrl {
    _sharedMySingleton = self;
    self.operationQueue = [[NSOperationQueue alloc] init];
    self.operationQueue.maxConcurrentOperationCount = 5;
    NSURL *url = [NSURL URLWithString:[NSString stringWithUTF8String: newsFeedUrl]];
    NSURLSession *session = [NSURLSession sharedSession];
    // show loader
    NSURLSessionDataTask *data = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSError *erro = nil;
        if (data!=nil) {
            
            NSArray *arrayJsonFeed = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&erro ];
            NSLog(@"json %@",arrayJsonFeed);
            NSString *newsDirectoryPath = [[self applicationDocumentsDirectory].path
                                           stringByAppendingPathComponent:@"/NewsFeedData"];
            if (![[NSFileManager defaultManager] fileExistsAtPath:newsDirectoryPath]){
                [[NSFileManager defaultManager] createDirectoryAtPath:newsDirectoryPath withIntermediateDirectories:false attributes:nil error:NULL];
            }
            NSString *newsPlistFilePath = [NSString stringWithFormat:@"%@/%@",newsDirectoryPath,@"NewsFeedData.plist"];
            NSError *fileExistanceError;
            [[NSFileManager defaultManager] removeItemAtPath:newsPlistFilePath error:&fileExistanceError];
            if (fileExistanceError){
                NSLog(@"fileExistanceError : %@",fileExistanceError);
            }
            [arrayJsonFeed writeToFile:newsPlistFilePath atomically:true];
            // download images
            [self downloadFiles:arrayJsonFeed];
        }
    }];
    
    [data resume];
}



/**
 Download all News feed images from urls received in Newsfeed json response
 */
- (void) downloadFiles: (NSArray *) fileArray {
    
    NSString *localDirectoryPath = [[self applicationDocumentsDirectory].path
                                    stringByAppendingPathComponent:@"/NewsFeedData"];
    NSLog(@"%@",localDirectoryPath);
    if (![[NSFileManager defaultManager] fileExistsAtPath:localDirectoryPath]){
        [[NSFileManager defaultManager] createDirectoryAtPath:localDirectoryPath withIntermediateDirectories:false attributes:nil error:NULL];
    }
    
    for (id fileInfo in fileArray) {
        
        NSString *fileName = [fileInfo valueForKey:@"id"];
        
        //Download file
        NSURL  *url = [NSURL URLWithString:[fileInfo valueForKey:@"newsPhoto"]];
        [self downloadImageUsingSession:url withLocalDirectoryPath:localDirectoryPath withFileName:fileName];
        
    }
    
}

/**
 Download images and saved them in documents directory
 */
-(void) downloadImageUsingSession:(NSURL *)url withLocalDirectoryPath:(NSString*)localDirectoryPath withFileName:(NSString*)fileName{
    
    NSURLSessionDownloadTask *downloadPhotoTask = [[NSURLSession sharedSession]
                                                   downloadTaskWithURL:url completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
                                                       NSString  *localPath = [NSString stringWithFormat:@"%@/%@", localDirectoryPath, fileName];
                                                       NSError *fileExistanceError;
                                                       [[NSFileManager defaultManager] removeItemAtPath:localPath error:&fileExistanceError];
                                                       
                                                       if (fileExistanceError){
                                                           NSLog(@"fileExistanceError : %@",fileExistanceError);
                                                       }
                                                       [[NSFileManager defaultManager] copyItemAtURL:location toURL:[NSURL fileURLWithPath:localPath] error:nil];
                                                       if(self.delegate){
                                                           [self.delegate downloadComepletedforImagenamed:fileName];
                                                       }
                                                       
                                                   }];
    
    [downloadPhotoTask resume];
}

/**
 Applications documents directory
 */
- (NSURL *)applicationDocumentsDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory
                                                   inDomains:NSUserDomainMask] lastObject];
}
@end
static iOSWebServiceManager *iOSWebservicePlugin = nil;

extern "C"
{    
    void _fetchAndSaveNewsFeedData(const char* newsFeedUrl) {
        if (iOSWebservicePlugin == nil){
            iOSWebservicePlugin = [[iOSWebServiceManager alloc] init];
        }
        [iOSWebservicePlugin _fetchAndSaveNewsFeedDataFromUrl:newsFeedUrl];
    }
}
