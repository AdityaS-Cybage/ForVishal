#!/usr/bin/env ruby
# ----------------------------------------------------------------------------------------------------------------------------------------------------------
#  SafeDK Setup Script for iOS
#  (c) 2018 SafeDK Ltd. All Rights Reserved
#
#  Syntax:
#    ruby SafeDKSetup-xyz.rb <command> <options>
#
#  Commands:
#    install - installs SafeDK onto an iOS target
#    uninstall - uninstalls SafeDK from a target
#    update - updates the SafeDK pod to the latest version, or to specific version if version number follows
#    adobeairupdate - updates the SafeDK Pod to the latest version including client ANE, or to specific version if version number follows
#    adobeairbuild - applies SafeDK to an IPA produced by Adobe Air
#
#  Options:
#    -targetid <target id> - installs on a specific target identified by its ID as appears in the xcodeproj file (applicable to "install" and "uninstall")
#    -targetname <target name> - installs on a specific target identified by its name (applicable to "install" and "uninstall")
#    -version <version> - installs a specific version and blocks automatic future updates (applicable to "install")
#    -pod <compressed pod file> - installs the given SafeDK pod instead of downloading from the SafeDK repository (applicable to "install")
#    -ipa <Adobe Air IPA file> - applies SafeDK to this IPA (applicable to "adobeairbuild")
#    -dsym <Adobe Air dSYM file> - required for Adobe Air builds (applicable to "adobeairbuild")
#    -buildconfiguration <Debug/Release/Other> - required bu Adobe Air builds (applicable to "adobeairbuild")
#
#  Examples:
#    ruby SafeDKSetup-xyz.rb  (when no parameters given, invokes the "install" command)
#    ruby SafeDKSetup-xyz.rb install -targetname MyTarget  (installs on target name "MyTarget")
#    ruby SafeDKSetup-xyz.rb install -pod SafeDKiOSPod-0.23.0.zip -version 0.23.0 (installs from local pod zip file, and fixes the version to 0.23.0)
#    ruby SafeDKSetup-xyz.rb uninstall
#    ruby SafeDKSetup-xyz.rb uninstall -targetname MyTarget
# ----------------------------------------------------------------------------------------------------------------------------------------------------------
require 'net/http'
require 'rexml/document'
require 'fileutils'
require 'date'

# Application-specific IDs
application_data=<<APPLICATION_DATA
{
  "app_id": "adee90f0affa125bddbc6c8f788ee4b5",
  "api_key": "83fc57f08f4aca8497873c992cbf6c09"
}
APPLICATION_DATA

# Internal
@version = '2.2.6'
@maven_server = "download.safedk.com"
@maven_root = "/maven"
@maven_group = "com/safedk"
@maven_group_id = "com.safedk"
@maven_artifact_id = "SafeDKiOSPod"
@maven_artifact_id_ane = "SafeDKAdobeAirClient"
@safedk_dir = "SafeDK"
@safedk_build_dir = "SafeDK_Build"
@version_file = "version.txt"
@last_update_file = "last_update.txt"
@installer_app = "SafeDKInstaller.app"
@check_interval = 24    # hours

@local_version = "0.0.0"
@fake_remote_version = "0.0.0"
@elapsed = @check_interval
@specific_version = nil
@target_id = nil
@target_name = nil


def error(msg)
  abort("\n#{msg}\nSAFEDK SETUP FAILED\n\n")
end


def create_safedk_dir

  Dir.mkdir(@safedk_full_dir) unless File.exist?(@safedk_full_dir)
  unless File.directory?(@safedk_full_dir)
    error("Failed to create the #{@safedk_dir} directory under #{@script_dir}")
  end

end

def delete_files_with_extension(dir, ext)

  Dir.entries(dir).each do |name|
    path = File.join(dir, name)
    if File.extname(name) == ext
      begin
        if File.directory?(path)
          FileUtils.rm_rf(path)
        else
          File.delete(path)
        end
      rescue Exception => e
        STDERR.puts("Failed to delete #{path}, reason: #{e}")
      end
    end
  end
end


def look_for_projects

  project_paths = []

  Dir.glob("#{@script_dir}/*.xcodeproj") do |path|
    project_paths << path
  end
  error("Could not find Xcode project file(s) under #{@script_dir}\n" +
            "Please copy this script to your Xcode project directory and run it from there.") unless project_paths.count > 0

  project_paths

end


def get_local_version
    local_version = "0.0.0"
    path = "#{@safedk_full_dir}/#{@version_file}"
    return local_version unless File.exist?(path)
    local_version = File.read(path)
    return "0.0.0" unless local_version
    local_version.strip
end


def get_last_update
    path = "#{@safedk_full_dir}/#{@last_update_file}"
    return nil unless File.exist?(path)
    content = nil
    content = File.read(path)
    return nil unless content
    DateTime.iso8601(content.strip)
end


def read_local_version_and_elapsed_time

  begin
    @local_version = get_local_version
    last_update = get_last_update
    if last_update
      @elapsed = (DateTime.now - last_update) * 24  # in hours
    end

  rescue
    # ignored
  end

end


def update_last_update_file

  begin
    path = "#{@safedk_full_dir}/#{@last_update_file}"
    File.open(path, 'w') { |file| file.write(DateTime.now.to_s) }

  rescue
    # ignored
  end

end


def get_latest_version

  # Retrieve Maven metadata
  maven_data = ""
  begin
    Net::HTTP.start(@maven_server, :open_timeout => 30) do |http|
      resp = http.get("#{@maven_root}/#{@maven_group}/#{@maven_artifact_id}/maven-metadata.xml")
      if resp.code.to_i >= 300
        error("Failed to retrieve SafeDK version information from server\n" +
                  "Server response code: #{resp.code}")
      end
      maven_data = resp.body
    end
  rescue
    puts "Failed to access SafeDK Maven repository"
    return @fake_remote_version
  end

  begin
    doc = REXML::Document.new maven_data
    group_id = doc.root.elements["groupId"].text
    artifact_id = doc.root.elements["artifactId"].text
    version = doc.root.elements["versioning/release"].text
  rescue
    puts "Failed to parse maven metadata received from server"
    return @fake_remote_version
  end

  # Some basic validation
  if group_id != @maven_group_id || artifact_id != @maven_artifact_id
    puts "Failed to properly parse Maven metadata"
    return @fake_remote_version
  end

  version

end


def should_check_for_updates

  return true unless @local_version
  return true if @specific_version && (@local_version != @specific_version)

  if @specific_version == @local_version
    puts "You already have SafeDK Pod version #{@specific_version}, no update required"
    return false
  end

  if @elapsed < @check_interval
    puts "SafeDK Pod was updated within the last #{@check_interval} hours"
    return false
  end
  return true

end


def newer_version_exists?

  @remote_version = get_latest_version
  return true if Gem::Version.new(@local_version) < Gem::Version.new(@remote_version)
  false

end


def ane_exists?
  @ane_file = "#{@safedk_full_dir}/#{@maven_artifact_id_ane}.ane"
  File.exist?(@ane_file)
end


def update_setup_file
    
    return unless File.exist?("#{@safedk_full_dir}/SafeDKSetup.rb")
    
    setup_content = File.read("#{@safedk_full_dir}/SafeDKSetup.rb")
    app_setup_content = File.read(__FILE__)

    maven_line = app_setup_content[/@maven_root\s*=.*?$/]
    setup_content.gsub!(/@maven_root\s*=.*?$/, maven_line)

    app_data_match = app_setup_content.scan(/(APPLICATION\_DATA.*APPLICATION\_DATA)/m)
    return if app_data_match.count == 0
    
    app_data = app_data_match.last.first
    setup_content.gsub!(/APPLICATION\_DATA.*APPLICATION\_DATA/m, app_data)
    File.write(__FILE__, setup_content)
    
    rescue Exception => msg
    error("Failed to update #{__FILE__} file, reason: #{msg}")
    
end


def inflate_pod(pod_zip_file)

  begin
    puts "Extracting SafeDK Pod into #{@safedk_dir} directory..."

    delete_files_with_extension(@safedk_full_dir, ".framework")
    delete_files_with_extension(@safedk_full_dir, ".app")

    is_ok = system("unzip -qq -o \"#{pod_zip_file}\" -d \"#{@safedk_full_dir}\"")
    unless is_ok
      error("Failed to unzip the SafeDK Pod")
    end
  rescue
    error("Failed to unzip the SafeDK Pod")
  end

  update_setup_file

end


def download_pod(version)

  if @compressed_pod

    puts "Using SafeDK Pod file #{@compressed_pod}..."
    pod_zip_file = @compressed_pod
    error("SafeDK Pod file #{pod_zip_file} could not be found") unless File.exist?(pod_zip_file)

  else

    pod_zip_file = "#{@maven_artifact_id}-#{version}.zip"
    begin
      puts "Downloading SafeDK Pod version #{version}..."
      Net::HTTP.start(@maven_server, :open_timeout => 30) do |http|
        resp = http.get("#{@maven_root}/#{@maven_group}/#{@maven_artifact_id}/#{version}/#{@maven_artifact_id}-#{version}.zip")
        if resp.code.to_i >= 300
          error("Failed to download SafeDK Pod version #{version} from server\n" +
                    "Server response code: #{resp.code}")
        end
        open(pod_zip_file, "wb") do |file|
          file.write(resp.body)
        end
      end
    rescue
      if @local_version
        puts "Failed to download the SafeDK Pod - continuing with current pod"
        return
      else
        error("Failed to download the SafeDK Pod")
      end
    end

  end

  inflate_pod(pod_zip_file)

  # cleanup
  begin
    File.delete(pod_zip_file) unless @compressed_pod
  rescue
  # ignored
  end

end


def download_ane(version)

  File.delete(@ane_file) if ane_exists?

  begin
    puts "Downloading SafeDK Adobe Air ANE version #{version}..."
    Net::HTTP.start(@maven_server, :open_timeout => 30) do |http|
      resp = http.get("#{@maven_root}/#{@maven_group}/#{@maven_artifact_id_ane}/#{version}/#{@maven_artifact_id_ane}-#{version}.ane")
      if resp.code.to_i >= 300
        error("Failed to download SafeDK Adobe Air ANE version #{version} from server\n" +
                  "Server response code: #{resp.code}")
      end
      open(@ane_file, "wb") do |file|
        file.write(resp.body)
      end
    end
  rescue Exception => e
    error(e.message)
  end

end


def apply_pod

  additional_params = ""
  additional_params += " -targetid #{@target_id}" if @target_id
  additional_params += " -targetname #{@target_name}" if @target_name
  additional_params += " -offline_mode" if @offline_mode
  invocation = "\"#{@safedk_full_dir}/#{@installer_app}/Contents/MacOS/SafeDKInstaller\" #{@command} -projectdir \"#{@current_dir}\" -setupfile \"#{@script_name}\" -nosig #{additional_params}"
  invocation += " -version #{@specific_version}" if @specific_version && (Gem::Version.new(get_local_version) > Gem::Version.new("0.22.2"))
  is_ok = system(invocation)

  unless is_ok
    error("Failed to apply the SafeDK Pod")
  end

end


def adobeair_download

  # Download pod and ANE
  newer_version_exists?
  required_version = @specific_version || @remote_version
  should_download = Gem::Version.new(@local_version) != Gem::Version.new(required_version) || !ane_exists?
  if should_download
    download_pod(required_version)
    download_ane(required_version)
  else
    puts "SafeDK Pod and ANE version #{@local_version} detected."
  end

end


def adobeair_build

  error("Missing mandatory command line parameter 'ipa'") unless @ipa
  error("Missing mandatory command line parameter 'dsym'") unless @dsym
  error("Missing mandatory command line parameter 'buildconfiguration'") unless @build_configuration

  # Invoke script to run extract IPA, run SafeDK Plugin and package back to IPA
  work_dir = "#{@script_dir}/#{@safedk_build_dir}"
  invocation = "\"#{@safedk_full_dir}/SafeDKAdobeAirBuild.rb\" -ipa \"#{@ipa}\" -dsym \"#{@dsym}\" -buildconfiguration #{@build_configuration} -workdir \"#{work_dir}\" -setupfile \"#{@script_name}\""
  is_ok = system(invocation)
  unless is_ok
    error("Failed to unzip the SafeDK Pod")
  end

end


def read_arg(i)
  if i+1 < ARGV.count
    return ARGV[i+1], i+1
  else
    return nil, i
  end
end


def read_command_line_options

  count = ARGV.count
  return unless count > 1
  i = 1
  while i < count
    case ARGV[i]
    when "-targetid"
      @target_id, i = read_arg(i)
    when "-targetname"
      @target_name, i = read_arg(i)
    when "-version"
      @specific_version, i = read_arg(i)
    when "-pod"
      @compressed_pod, i = read_arg(i)
    when "-ipa"
      @ipa, i = read_arg(i)
    when "-dsym"
      @dsym, i = read_arg(i)
    when "-buildconfiguration"
      @build_configuration, i = read_arg(i)
    when "-offline_mode"
      @offline_mode = true
    else
      error("Unrecognized command line option #{ARGV[i]}")
    end
    i += 1
  end

end


def read_command_line_args

  @command = case ARGV[0]
             when nil
               "install"
             when "install"
              read_command_line_options
               "install"
             when "uninstall"
              read_command_line_options
               "uninstall"
             when "update"
               @specific_version = ARGV[1]
               "update"
             when "adobeairupdate"
               @specific_version = ARGV[1]
               "adobeairupdate"
             when "adobeairbuild"
               read_command_line_options
               "adobeairbuild"
             else
               puts "Unrecognized command: #{ARGV[0]}"
               puts "Usage: ruby #{File.basename($0)} <command> <options>"
               puts "Where:"
               puts "  command - install | uninstall | update | adobeairupdate | adobeairbuild"
               exit(0)
             end
end


def print_end_message

  if @command == "install" then
    puts "If you decide to uninstall the SafeDK Pod at any stage, you may run:"
    puts "ruby #{File.basename($0)} uninstall"
    puts "In case you encounter any issues, please contact us at support@safedk.com"
  elsif @command == "uninstall" then
    puts "If you uninstalled SafeDK from all of your targets and projects and no longer need it,"
    puts "you may manually delete the #{@safedk_dir} directory under your project,"
    puts "as well as delete this #{File.basename($0)} script."
    puts "In case you encounter any issues, please contact us at support@safedk.com"
  end

end


class String
  def escape
    self.force_encoding("UTF-8").gsub(/[\\\"`$]/){|m| '\\' + m }
  end
end


STDOUT.sync = true
puts "-------------------------------------------------"
puts " SafeDK Xcode Setup Script #{"Version #{@version}" if @version}"
puts " 2018 SafeDK Ltd. All Rights Reserved."
puts "-------------------------------------------------"


@script_dir = File.expand_path(File.dirname(__FILE__))
@safedk_full_dir = "#{@script_dir}/#{@safedk_dir}"
@script_name = File.basename($0).escape
@current_dir = Dir.pwd.escape


read_command_line_args
create_safedk_dir
read_local_version_and_elapsed_time

if @command == "adobeairupdate"
  adobeair_download
  exit(0)
end

if @command == "adobeairbuild"
  adobeair_build
  exit(0)
end



look_for_projects unless @command == "update" # This makes sure we found at least one xcode project file

exit(0) if @command == "update" && !should_check_for_updates

if @command == "install" || @command == "update"

  if @specific_version
    download_pod(@specific_version)
  else
    puts "Checking SafeDK installed versions..."
    if newer_version_exists?
      download_pod(@remote_version)
    else
      puts "You already have the latest SafeDK Pod." if @remote_version != @fake_remote_version
    end
  end

end

unless @command == "update"

  puts
  apply_pod
  print_end_message

end

update_last_update_file
puts "..DONE"
