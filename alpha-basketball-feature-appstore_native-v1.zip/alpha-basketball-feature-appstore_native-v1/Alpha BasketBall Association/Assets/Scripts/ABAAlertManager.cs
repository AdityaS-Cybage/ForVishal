﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ABAAlertManager : MonoBehaviour {


	// Use this for initialization
	void Start () {
		
	}
    
	// Update is called once per frame
	void Update () {
		
	}

	public static void showAlertUser(){
		Constants.sharedInstance.alertPanel.SetActive (true);
		Constants.sharedInstance.alertTextUser.SetActive (true);
	}

	public static void showAlertConnection(){
		Constants.sharedInstance.alertPanel.SetActive (true);
		Constants.sharedInstance.alertTextConnection.SetActive (true);
	}

	public static void HideAlert(){

		Constants.sharedInstance.alertPanel.SetActive (false);
		Constants.sharedInstance.alertTextUser.SetActive (false);
		Constants.sharedInstance.alertTextConnection.SetActive (false);
	}

	public void OnClickOkButton ()
	{
		print ("OnClickOkButton");
		Constants.sharedInstance.alertPanel.SetActive (false);
		Constants.sharedInstance.alertTextUser.SetActive (false);
		Constants.sharedInstance.alertTextConnection.SetActive (false);
	}
}


