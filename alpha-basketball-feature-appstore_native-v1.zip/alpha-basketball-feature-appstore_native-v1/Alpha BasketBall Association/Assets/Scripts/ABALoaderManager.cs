﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ABALoaderManager : MonoBehaviour {

    public GameObject loaderPanel;
    private static ABALoaderManager _instance;
    public static ABALoaderManager sharedInstance { get { return _instance; } }

    private void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;
        }
    }
	    // Use this for initialization
	
    public void showLoader(){
        print("$$ABA-APPSTORE: Show Loader");
        loaderPanel.SetActive(true);
    }

    public void HideLoader(){
        print("$$ABA-APPSTORE: Hide Loader");
        loaderPanel.SetActive(false);
    }
}
