﻿
//#if !UNITY_EDITOR
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Internal;
using UnityEngine.Scripting;
using System.Runtime.InteropServices;
using System;

// This singleton class will handle all Ads transactions.
public class Advertisment : MonoBehaviour
{
    private static Advertisment _instance;

    public static Advertisment sharedInstance { get { return _instance; } }

    // Android constants and PlacementIDs pointing to Vungle test applications on the dashboard for android

    const string pluginName = "com.unityplugin.unityandroidplugin.MyPluginClass";
    const string defaultClassName = "com.unity3d.player.UnityPlayer";

    static AndroidJavaClass _pluginClass;
    static AndroidJavaObject _pluginInstance;

    // const string gameObject = "gameObject";
    const string callbackAdEndMethod = "RewardedAdViewedCompletely";
    const string callbackAdLoadMethod = "RewardedAdAvailableEvent";

    // method names
    const string initializeSDK = "initializeSDK";
    const string playInterstitialAd = "playInterstitialAd";
    const string playRewardedAd = "playRewardedAd";
    const string playBannerAd = "playBannerAd";

    private string app_id;
    private string autoCachePlacementReferenceID;
    private string rewardedPlacementReferenceID;
    private string bannerAdPlacementID;
    private string inFeedAdplacementID;
    private string bannerAdSize;
    private string inFeedAdType;

#if UNITY_IOS
    [DllImport("__Internal")]
	private static extern void _initializeSDK(string appID,string rewardedPlacementID, string interstitialPlacementID, string bannerAdId, string flexFeedAdId ,string gameObjectname, string methodAdViewed, string methodAdAvailable, string testId, string username, string bannerAdSize, string inFeedAdType);
    [DllImport("__Internal")]
    private static extern void _playInterstitial();
    [DllImport("__Internal")]
    private static extern void _loadRewardedAd();
    [DllImport("__Internal")]
    private static extern void _playRewardedAd();
    [DllImport("__Internal")]
    private static extern void _addBannerView(string username);

#endif

    private void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;
        }
    }


    void Start()
    {
        GetAdsConfigurations();
        InitailiseSDK();
    }

    private void GetAdsConfigurations()
    {
        app_id = WebServiceManager.sharedInstance.GetConfigParamAppId();
        autoCachePlacementReferenceID = WebServiceManager.sharedInstance.GetConfigParamInterstitialAdId();
        rewardedPlacementReferenceID = WebServiceManager.sharedInstance.GetConfigParamRewardedAdId();
        bannerAdPlacementID = WebServiceManager.sharedInstance.GetConfigParamBannerAdId();
        inFeedAdplacementID = WebServiceManager.sharedInstance.GetConfigParamInFeedAdId();
        bannerAdSize = WebServiceManager.sharedInstance.GetConfigParamBannerAdSize();
        inFeedAdType = WebServiceManager.sharedInstance.GetConfigParamInFeedAdType();
    }

    // Initailise - Android and IOS SDKs
    private void InitailiseSDK()
    {
#if UNITY_IOS
		_initializeSDK (app_id,rewardedPlacementReferenceID,autoCachePlacementReferenceID, bannerAdPlacementID, inFeedAdplacementID, this.gameObject.name,"RewardedAdViewedCompletely","RewardedAdAvailableEvent", WebServiceManager.sharedInstance.GetConfigParamTestId(),PlayerPrefs.GetString(Constants.KEY_USERNAME, null),bannerAdSize,inFeedAdType);
#elif UNITY_ANDROID
        InitializeAndroidSDK();
#endif
    }

    // Initailise - Android SDK
    private void InitializeAndroidSDK()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            AndroidJavaObject myPluginObject = new AndroidJavaObject(pluginName);

            string gameObjectName = this.gameObject.name;
            myPluginObject.Call(initializeSDK, app_id, autoCachePlacementReferenceID,
                rewardedPlacementReferenceID, bannerAdPlacementID, inFeedAdplacementID,
                gameObjectName, callbackAdEndMethod, callbackAdLoadMethod,
                PlayerPrefs.GetString(Constants.KEY_USERNAME, null), bannerAdSize, inFeedAdType);
        }
    }

    // Play Interstitial Ad
    public void PlayGameEndAd()
    {
#if UNITY_IOS
		_playInterstitial();
#elif UNITY_ANDROID
        PlayInterstitialAdAndroid();
#endif
    }

    // Plays the interstitial ad android.
    private void PlayInterstitialAdAndroid()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            AndroidJavaObject myPluginObject = new AndroidJavaObject(pluginName);

            myPluginObject.Call(playInterstitialAd, autoCachePlacementReferenceID);
        }

    }

    // Load Rewarded Ad
    public void LoadRewardedAd()
    {
#if UNITY_IOS
		_loadRewardedAd();
#elif UNITY_ANDROID
        LoadRewardedAdAndroid();
#endif
    }

    // Loads the rewarded ad android.
    private void LoadRewardedAdAndroid()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            AndroidJavaObject myPluginObject = new AndroidJavaObject(pluginName);

            myPluginObject.Call("loadRewardedAd", rewardedPlacementReferenceID);
        }
    }

    // Plays the rewarded ad.
    public void PlayRewardedAd()
    {
#if UNITY_IOS
		_playRewardedAd();
#elif UNITY_ANDROID
        PlayRewardedAdAndroid();
        StartCoroutine(WaitForButtonDisable());
#endif


    }

    private IEnumerator WaitForButtonDisable()
    {
        yield return new WaitForSeconds(1.0f);
        Constants.sharedInstance.rewardedAdButton.interactable = false;
        LoadRewardedAd();
    }

    // Plays the rewarded ad android.
    private void PlayRewardedAdAndroid()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            AndroidJavaObject myPluginObject = new AndroidJavaObject(pluginName);

            myPluginObject.Call(playRewardedAd, rewardedPlacementReferenceID);
        }
    }

    // Plays the banner ad android.
    private void PlayBannerAdAndroid(string playerName)
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            AndroidJavaObject myPluginObject = new AndroidJavaObject(pluginName);

            myPluginObject.Call(playBannerAd, playerName);
        }
    }


    public void AddBannerAdView()
    {
#if UNITY_IOS
        _addBannerView(PlayerPrefs.GetString(Constants.KEY_USERNAME,null)); 
#elif UNITY_ANDROID
        PlayBannerAdAndroid(PlayerPrefs.GetString(Constants.KEY_USERNAME, null));
#endif
    }
    // Callback method for ad viewed completely
    private void RewardedAdViewedCompletely(string adviewstatus)
    {
        print("$$ABA-APPSTORE: RewardedAdViewedCompletely ad view status : " + adviewstatus);

        if (!Constants.sharedInstance.IsGameEndRewardedAd())
        {
            if (adviewstatus == "1" && Constants.durationOfRound >= 20 && Constants.durationOfRound < 40)
            {
                Constants.durationOfRound = Constants.durationOfRound + 5;

                if (Constants.durationOfRound == 40)
                {
                    Constants.sharedInstance.rewardedAdButton.interactable = false;
                }

            }
        }
        else
        {
            print("$$ABA-APPSTORE: RewardedAdViewedCompletely - IsGameEndRewardedAd");
            if (adviewstatus == "1")
            {
                // add 5 secs and decrease 10 points.
                print("$$ABA-APPSTORE: RewardedAdViewedCompletely - Add score!");
                ManageExtendedPlaytime();
            }
            else
            {
                Constants.sharedInstance.CloseGameEndPopup();
                print("$$ABA-APPSTORE: RewardedAdViewedCompletely - Closing Game end popup");
            }
        }

        if (adviewstatus == "1")
        {
            int currentAdViewCount = PlayerPrefs.GetInt(Constants.KEY_AD_VIEW_COUNT);
            if (FirebaseManager.sharedInstance != null && FirebaseManager.sharedInstance.GetContestStatus())
            {
                print("$$ABA-APPSTORE: **** Contest is running");
                currentAdViewCount++;
                PlayerPrefs.SetInt(Constants.KEY_AD_VIEW_COUNT, currentAdViewCount);
            }
            print("$$ABA-APPSTORE: **** currentAdViewCount ---" + currentAdViewCount.ToString());
            print("$$ABA-APPSTORE: **** Constants.adViewCountPar ---" + Constants.adViewCountPar.ToString());
            if (currentAdViewCount >= Constants.adViewCountPar)
            {
                // add 5 secs to next game.
                print("$$ABA-APPSTORE: **** inside if");
                PlayerPrefs.SetInt(Constants.KEY_ADDITIONAL_TIME, 1);
            }
        }

#if UNITY_ANDROID
        LoadRewardedAd();
#endif
    }

    public void ManageExtendedPlaytime()
    {
        // inc time
        // dec score
       // Constants.sharedInstance.gameEndPopupOverlay.SetActive(false);
        Constants.durationOfRound = 5;
        ScoreManager.sharedInstance.DecreaseScore(Constants.sharedInstance.CalculatePenalty());
		Constants.sharedInstance.CountdownOverlayPanel.SetActive (true);
       // Constants.sharedInstance.ResumeGame();
    }

    

    // Callback method for ad loaded successfully.
    private void RewardedAdAvailableEvent(string playableState)
    {
        print("$$ABA-APPSTORE: $$$ RewardedAdAvailableEvent called playabele state " + playableState);

        Constants.sharedInstance.rewardedAdButton.interactable = (playableState == "1" && (Constants.durationOfRound >= 20 || Constants.durationOfRound <= 40) && Constants.durationOfRound != 40);

        if (playableState == "1" && Constants.sharedInstance.getGameEndPopUpCount() < 5)
        {
            Constants.sharedInstance.setGameEndAdAvailable(true);
        }
        else
        {
            Constants.sharedInstance.setGameEndAdAvailable(false);
        }
    }
}

//#endif