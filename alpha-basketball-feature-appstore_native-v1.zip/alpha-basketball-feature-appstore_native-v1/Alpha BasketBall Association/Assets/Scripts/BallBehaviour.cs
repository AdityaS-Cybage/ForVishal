using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Threading;

// This class handles behaviour of ball during its lifecycle.
// Ball Rotation, scaling, upword force, downword force.
// Each ball has this class attached to it.
public class BallBehaviour : MonoBehaviour
{
	private Rigidbody2D rigidBody;
	private CircleCollider2D ballCollider;
	private bool shouldInstantiateNewBall = false;
	private bool isForceAdded = false;
	private Direction rotationDirection = Direction.Up;
	private float radius = 0;
	private float pointWhereNewBallShouldBeCreated = 0.0f;
	private float pointUptoWhichBallShouldScaleWhilegoingDown = 0.0f;
	private float maximumHeightBallShouldReach = 0.0f;
	private bool shouldScale = true;
	private bool isFadingStarted = false;
    private bool didCollideWithBouncingPads = false;
    private float ballY = 0.0f;
    private float hoopTop = 0.0f;
    private float ballSizeMax = 0.0f;
    private float ballSizeMin = 0.0f;
    private float oldYOfBall = 0.0f;
    private float variationFactor = 0.0f;
    private float maxGravityScaleValue = 0.0f;
    private int counter = 0;
    private float multipliationFactorForRotationWhileGoingDown = 0.0f;
    private float minRotationAngle = 0.0f;
    private float maxRotationAngleWhileGoingUp = 0.0f;



    void Awake ()
	{
		rigidBody = GetComponent<Rigidbody2D> ();
		ballCollider = GetComponent<CircleCollider2D> ();
	}

	void Start ()
	{
		radius = Constants.sharedInstance.GetBallSize () / 2;
        pointWhereNewBallShouldBeCreated = Constants.sharedInstance.GetPointWhereNewBallShouldBeCreated(); //(Constants.DEVICE_HEIGHT / 4); //+ (radius / 4); 
		pointUptoWhichBallShouldScaleWhilegoingDown = Constants.sharedInstance.GetHoopBarTop ()
		+ (Constants.sharedInstance.GetBallSize () / 2);
		maximumHeightBallShouldReach = Constants.sharedInstance.GetHoopBottom() - (radius/2);

        ballY = transform.position.y;
        hoopTop = Constants.sharedInstance.GetHoopTop();
        ballSizeMax = 1.0f; //radius * 2.0f;
        ballSizeMin = 0.55f; //ballSizeMax / 1.583f;
        maxRotationAngleWhileGoingUp = 180;
        minRotationAngle = 0.0f;
        oldYOfBall = ballY;
          
        maxGravityScaleValue = WebServiceManager.sharedInstance.GetConfigParamGravityValue();
        print("$$ABA-APPSTORE: Max gravity scale value " + maxGravityScaleValue.ToString());
       
        variationFactor = (Constants.sharedInstance.GetBallTravelDistance() - ballY) / (ballSizeMax - ballSizeMin);
        multipliationFactorForRotationWhileGoingDown = maxRotationAngleWhileGoingUp / (Constants.sharedInstance.GetHoopTop() - Constants.sharedInstance.GetFloorHeight());
    }

   
	void FixedUpdate ()
	{
		if (rigidBody != null) {

			if (rigidBody.velocity.y > 0) {
                rigidBody.gravityScale = Mathf.Clamp(transform.position.y, 1, maxGravityScaleValue);
            } 
        
		}
	}

    void Update()
    {
        if (rigidBody != null)
        {
            if (rigidBody.velocity.y > 0)
            {
                UpwordTrajectoryBallBehaviourNew();
            }
            else if (rigidBody.velocity.y < -0.1f)
            {
                DownwordTrajectoryBallBehaviourNew();
            }
            OutsideScreenBallBehaviour();
        }
    }
   


    private void UpwordTrajectoryBallBehaviourNew()
    {
        float i = transform.position.y;
       
        RotateBall();
     
        if (Constants.sharedInstance.IsThisNoScoreAttempt()) {
            float val = transform.localScale.y + 0.005f;
            val = Mathf.Clamp(val, 1.0f, 1.05f);
            transform.localScale = new Vector3(val, val, val);
        } else {
            float ballSizeCalculated = Mathf.Clamp(ballSizeMax - ((i - oldYOfBall) / (variationFactor)), ballSizeMin, ballSizeMax);
            ballSizeCalculated = Mathf.Clamp(ballSizeCalculated, ballSizeCalculated, ballSizeMax);
            transform.localScale = new Vector3(ballSizeCalculated, ballSizeCalculated, ballSizeCalculated);
        }


        if (transform.position.y > pointWhereNewBallShouldBeCreated)
        {
            if (shouldInstantiateNewBall == false)
            {
               shouldInstantiateNewBall = true;
                Constants.sharedInstance.CloneBall();
            }
                
        }

     }


    //behaviour of ball while going down.
    private void DownwordTrajectoryBallBehaviourNew()
    {
        // update sibling position of ball.
        if (transform.position.y > (Constants.sharedInstance.GetHoopBottom() + (1.5 * radius))) {

            transform.SetSiblingIndex(2);
            this.gameObject.layer = (int)Layer.BallHoopCollisionLayer;
        } else { 
        
            if (transform.position.y < pointWhereNewBallShouldBeCreated) {
                transform.SetSiblingIndex(2);
                this.gameObject.layer = (int)Layer.BallHoopCollisionLayer;
            }
        }

        RotateBall();
        if (counter < 1)
        {
            counter++;
            rigidBody.gravityScale = 100.0f;
            if (!Constants.sharedInstance.IsThisNoScoreAttempt())
            {
                float val = transform.localScale.y - (counter / 100f);
                transform.localScale = new Vector3(val, val, val);
            }

        }
        else
        {
            rigidBody.gravityScale = Constants.sharedInstance.GetBallTravelDistance();//(Constants.DEVICE_HEIGHT/2); 
            if (transform.position.y >= Constants.sharedInstance.GetBallTravelDistance() && !Constants.sharedInstance.IsThisNoScoreAttempt())
            {
                float ballScaleWhenGoingDownFromTop = Mathf.Clamp(transform.localScale.y - 0.01f, ballSizeMin, transform.localScale.y);
                transform.localScale = new Vector3(ballScaleWhenGoingDownFromTop, ballScaleWhenGoingDownFromTop, ballScaleWhenGoingDownFromTop);
            }

        }

        // start fading the ball
        if (transform.position.y < (pointWhereNewBallShouldBeCreated + radius))
        {
            if (isFadingStarted == false)
            {
                isFadingStarted = true;
                gameObject.GetComponent<Image>().CrossFadeAlpha(0.3f, Constants.sharedInstance.GetBallCrossFadeDuration(), false);
            }
        }

    }



    // Ball behaviour when it goes outside screen
    private void OutsideScreenBallBehaviour ()
	{
		if ((transform.position.x > ((Screen.width) + (2 * radius))) || (transform.position.x < -(2 * radius)) ||
		          (transform.position.y > Screen.height + 2 * radius) || (transform.position.y < 0f)) {
            Destroy (gameObject);

		}
	}
    public void AddForceTowardsHoop()
    {
        float padForce = WebServiceManager.sharedInstance.GetConfigParamPadForce();
        print("$$ABA-APPSTORE: Padforce " + padForce.ToString());
        rigidBody.AddForce(new Vector3(0, padForce, 0));
    }

   

	public void ThrowWithForceNew (Vector3 force){

		if (rigidBody != null && isForceAdded == false) {
			isForceAdded = true;

			rigidBody.AddForce(force * 90.0f);
          
            if (force.x > 0.12) {
				rotationDirection = Direction.Right;
			} else if (force.x < -0.12) {
				rotationDirection = Direction.Left;
			} else {
				rotationDirection = Direction.Up;
			}

			Constants.sharedInstance.RemoveShadow (force.x);
		}
	}

	private void RotateBall ()
	{
		if (rotationDirection == Direction.Left) {
			
			transform.Rotate (new Vector3 (0, 0, Time.fixedDeltaTime * Constants.ballRotationSpeed));
		} else {
			transform.Rotate (new Vector3 (0, 0, -Time.deltaTime * Constants.ballRotationSpeed));
		}
	}

	// This function gets called when ball collides with hoop
	void OnCollisionEnter2D (Collision2D collision)
	{
		if (collision.collider.name == Constants.hoopColliderName) {
			shouldScale = false;
		}
        if (collision.collider.tag == Constants.bouncingPadTag) {
            didCollideWithBouncingPads = true;
        }
	}

    public bool DidCollideWithBouncingPads()
    {
        return didCollideWithBouncingPads;
    }
   }
