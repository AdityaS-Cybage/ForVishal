﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BouncingPadLeft : MonoBehaviour {

    private Animator alphaAnimator;
    // Use this for initialization
    void Start () {
        alphaAnimator = this.GetComponent<Animator>();

    }
	
	// Update is called once per frame
	void Update () {
		
	}

    // This function get called when any collision is detected by Bouncing pad
    void OnCollisionEnter2D(Collision2D collision)
    {
        // If collision is with ball show animation
        if (collision.collider.tag == Constants.ballTag)
        {
            print("$$ABA - APPSTORE: "+ collision.collider.gameObject.name + " hit left pad");
            alphaAnimator.enabled = true;
            alphaAnimator.Play("LeftPadAnimation", -1, 0.0f);
            collision.collider.gameObject.GetComponent<BallBehaviour>().AddForceTowardsHoop();
        }

    }
}
