﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum Direction
{
    Up,
    Left,
    Right}
;

public enum HomeScreenScoreUI
{
    None,
    BestScore,
    LastScore}
;

public enum Layer
{
    BallLayer = 8,
    FloorLayer = 9,
    BallHoopCollisionLayer = 11,
    Obstacle = 12,
}
// This Class has all constants, Predefined values.
// This class is initialized at very beginning of game. So it also sets up all UI and game components
public  class Constants : MonoBehaviour
{
    private static Constants _instance;

    public static Constants sharedInstance { get { return _instance; } }

    public GameObject floorPrefab;
    public GameObject ballPrefab;
    public GameObject hoopPrefab;
    public GameObject hoopBarPrefab;
    public GameObject shadowPrefab;
    public GameObject homeScreenPanel;
    public GameObject playModePanel;
    public GameObject launchScreenPanel;
    public GameObject bestScorePanel;
    public GameObject lastScorePanel;
    public GameObject topElementsPanel;
    public GameObject userNameInputPanel;
	public GameObject alertPanel;
	public GameObject alertTextUser;
	public GameObject alertTextConnection;
    public Button rewardedAdButton;
    public Button leaderBoardButton;
    public Button newsFeedButton;
    public Text userNameText;
	public bool Login;
    public GameObject scoreManager;
    public GameObject rightPadPrefab;
    public GameObject leftPadPrefab;
    public GameObject obstaclePrefab;
    public GameObject gameEndPopupOverlay;
	public GameObject CountdownOverlayPanel;
    public Canvas currentcanvas;
   

    private GameObject ballReferance;
    private GameObject hoopBarReferance;
    private GameObject floorReferance;
    private Transform parentTransform;
    private GameObject hoopReferance;
    private GameObject shadowReferance;
    private GameObject rightPadReferance;
    private GameObject leftPadReferance;
    private GameObject obstacleReferance;
    private BoxCollider2D hoopBoxColliderForNoScore;

    private float hoopY;
    private float touchIgnorePointBottom = 0.0f;
    private float touchIgnorePointTop = 0.0f;
	private Sprite[] ballSprites;
	private Sprite currentSprite;

    // Constants for Last score and Best Score
    // Move these lines to other file
    public static string KEY_LAST_SCORE = "KEY_LAST_SCORE";
    public static string KEY_BEST_SCORE = "KEY_BEST_SCORE";
    public static string KEY_USERNAME = "KEY_USERNAME";
    public static string KEY_FIRST_INSTALL = "KEY_FIRST_INSTALL";
    public static string KEY_AD_VIEW_COUNT = "KEY_AD_VIEW_COUNT";
    public static string KEY_ADDITIONAL_TIME = "KEY_ADDITIONAL_TIME";

    //Leaderboard URL
    // staging : https://sdemostaging.wpengine.com/leaderboard-scoring/
    //local : http://172.27.237.97:8080/salesdemoapp/leaderboard-scoring/
    //production : https://alpha-basketball.firebaseapp.com

    // Animation clips name
    public static string HoopMovementFor10sec = "HoopMovementFor10sec";
    public static string HoopMovementFor10sec_New = "HoopMovementFor10sec_New";
    public static string HoopBarMovementFor10sec_New = "HoopBarMovementFor10sec_New";
    public static string HoopMovementFor15secCurve = "HoopMovementFor15secCurve";
    public static string HoopBarMovementFor15secCurve = "HoopBarMovementFor15secCurve";
    public static string HoopMovementFor05sec_option1 = "HoopMovementFor05sec_option1";
    public static string HoopMovementFor05sec_option2 = "HoopMovementFor05sec_option2";
    public static string HoopMovementFor05sec_option3 = "HoopMovementFor05sec_option3";
    public static string HoopBarMovementFor05Sec_Option2 = "HoopBarMovementFor05Sec_Option2";
    public static string HoopBarMovementFor05Sec_Option3 = "HoopBarMovementFor05Sec_Option3";
    // STD RESOLUTION : 1920 X 1080 PX
    private static float STD_DEVICE_HEIGHT = 1920f;
    private static float STD_DEVICE_WIDTH = 1080f;

    // DEVICE RESOLUTION
    public static float DEVICE_HEIGHT = Screen.height;
    public static float DEVICE_WIDTH = Screen.width;

    // VALUES ACCORDING TO STD RESOLUTION : 1920 X 1080 PX
    private static float UPWORD_SPEED_CONSTANT = 3575f;
    private static float DOWNWORD_SPEED_CONSTANT = 300f;
    private static float TRAVEL_DISTANCE_FOR_BALl_CONSTANT = 1430f;

    // DEVICE RESOLUTION FACTORS
    public static float DEVICE_RESOLUTION_HEIGHT_FACTOR = DEVICE_HEIGHT / STD_DEVICE_HEIGHT;
    public static float DEVICE_RESOLUTION_WIDTH_FACTOR = DEVICE_WIDTH / STD_DEVICE_WIDTH;

    private static float TRAVEL_DISTANCE_FOR_BALL = DEVICE_HEIGHT;

    // VALUES ACCORDING TO CURRENT RESOLUTION OF DEVICE
    public static float UPWORD_SPEED_MULTIPLIER;
    public static float DOWNWORD_SPEED_MULTIPLIER;

    public static int adViewCountPar = 5;
    public static int additionalTime = 5;
    public static float goingUpShrinkSpeed = 0.5f;
    public static float goingDownShrinkSpeed = 1.4f;
    public static int ballRotationSpeed = 500;
    public static int durationOfRound = 20;
    public static HomeScreenScoreUI scoreUI = HomeScreenScoreUI.None;
    public static string hoopColliderName = "Hoop";
    public static string bouncingPadTag = "BouncingPad";

    public static string ballTag = "Ball";

    //private Transform floorTransform;
    private Transform hoopTransform;
    private float topSpacing;
    private float bottomSpacing;
    private bool isThisFirstSwipeDone = false;

    private float hoopYCordinate = 480f;
    private float hoopBarYCordinate = 220f;
    private float floorColliderYOffset = -75.5f;
    private float ballShadowOffset = -65f;
    private string userName = "Test User";
    private bool areBouncingPadsEnabled = false;
    private int gameAttemptCounter = 0;
    private bool isThisNoScoreAttempt = false;
    private bool isThisGameEndRewardedAd = false;
    private int gameEndPopUpCount = 0;
    private bool isGameEndAdAvailable = false;
    private bool holdTimerTillAdView = false;

    private void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;
        }
    }

    void Start()
    {
        //DEVICE_RESOLUTION_HEIGHT_FACTOR = currentcanvas.GetComponent<RectTransform>().sizeDelta.y / STD_DEVICE_HEIGHT;
        
        #if UNITY_IPHONE
		float yPositionOfTopElement = Screen.height - (120f * DEVICE_RESOLUTION_HEIGHT_FACTOR);
		if (Screen.safeArea.height < Screen.height) {
			yPositionOfTopElement = yPositionOfTopElement - 44;
		}
		topElementsPanel.transform.position = new Vector3 (topElementsPanel.transform.position.x, yPositionOfTopElement, topElementsPanel.transform.position.z);
        #endif

        // Set frame rate to 60 for all the device
        if (Application.targetFrameRate < 60)
        {
            Application.targetFrameRate = 60;
        }

        if(DEVICE_RESOLUTION_HEIGHT_FACTOR > 1.333) {
            Application.targetFrameRate = 57;
        }
        //Application.targetFrameRate = 56;

        if (WebServiceManager.sharedInstance.GetConfigParamAdsEnabled()) {
            #if !UNITY_EDITOR
            gameObject.AddComponent<Advertisment> ();
            #endif
        }

        if (WebServiceManager.sharedInstance.GetConfigParamFirebaseEnabled())
        {
            gameObject.AddComponent<FirebaseManager>();
        }

        rewardedAdButton.interactable = false;
        gameEndPopupOverlay.SetActive(false);
        parentTransform = Constants.sharedInstance.playModePanel.GetComponent<Transform>();

        // Instantiate Hoop
        InitiateHoop();
        //In floor new
        float floorHeight = ((DEVICE_HEIGHT / 2) - (673 * currentcanvas.GetComponent<RectTransform>().localScale.y))/ currentcanvas.GetComponent<RectTransform>().localScale.y;
        print("$$ABA-APPSTORE: " + floorHeight);
        InitiateFloor(floorHeight);

        // Instantiate HoopBar.
        InitiateHoopBar();
        // Define top and bottom spacing values
        InitiateUISepcificValues(floorHeight);
        //Instantiate Bouncing pads and obstacle
        InitiatePadsAndObstacle();
        //Disable Pads and obstacle
        DisablePadsAndObstacles();
        // enable home screen 
        homeScreenPanel.GetComponent<HomeScreenManager>().enabled = true;

        touchIgnorePointBottom = 0.05f * DEVICE_HEIGHT; //200 * DEVICE_RESOLUTION_HEIGHT_FACTOR;
        touchIgnorePointTop = Constants.DEVICE_HEIGHT - ((Constants.DEVICE_RESOLUTION_HEIGHT_FACTOR*180) + 120);
        // Enable Swipe Script of Panel
        EnableSwipeScriptofPanel();

        CloneBall();
        HomeScreenActivation(true);
        InvokeRepeating("checkInterntConenction", 0.0f, 2.0f);

        scoreManager.SetActive(true);
        print("$$ABA-APPSTORE: Floor height : " + GetFloorHeight().ToString());
    }

    private void InitiateHoop()
    {
        Vector3 hoopReferancePosition = new Vector3(0f, hoopYCordinate, 0f);
        hoopReferance = Instantiate(hoopPrefab, hoopReferancePosition, Quaternion.identity) as GameObject;
        hoopReferance.transform.SetParent(parentTransform, false);
        hoopReferance.transform.SetAsLastSibling();
        hoopTransform = hoopReferance.GetComponent<Transform>();
        hoopY = hoopTransform.GetComponent<RectTransform>().position.y;
        hoopBoxColliderForNoScore = hoopReferance.GetComponent<BoxCollider2D>();
    }

    private void InitiateFloor(float floorHeight)
    {
        //In floor new
        Transform floorTransform = floorPrefab.transform;
  
     float floorYPosition = -((floorHeight / 2) + (673));

        Vector3 floorReferancePosition = new Vector3(0f, floorYPosition, 0f);
        floorReferance = Instantiate(floorPrefab, floorReferancePosition, Quaternion.identity) as GameObject;
        floorReferance.GetComponent<RectTransform>().sizeDelta = new Vector2(STD_DEVICE_WIDTH, floorHeight);
        floorReferance.GetComponent<BoxCollider2D>().offset = new Vector2(0, floorColliderYOffset );
        floorReferance.GetComponent<BoxCollider2D>().size = new Vector2(STD_DEVICE_WIDTH, floorHeight + (floorColliderYOffset * 2 ));
        floorReferance.transform.SetParent(parentTransform, false);
        floorReferance.transform.SetAsLastSibling();
        floorTransform = floorReferance.GetComponent<Transform>();

    }

    private void InitiateHoopBar()
    {
        // Instantiate HoopBar.
        Vector3 hoopBarReferancePosition = new Vector3(0f, hoopBarYCordinate, 0f);
        hoopBarReferance = Instantiate(hoopBarPrefab, hoopBarReferancePosition, Quaternion.identity) as GameObject;
        hoopBarReferance.transform.SetParent(parentTransform, false);
        hoopBarReferance.transform.SetSiblingIndex(parentTransform.childCount - 2);

    }

    private void InitiateUISepcificValues(float floorHeight)
    {
        // Define top and bottom spacing values
        bottomSpacing = floorHeight;
        topSpacing = ((DEVICE_HEIGHT) - (hoopY
        + (hoopTransform.GetComponent<RectTransform>().sizeDelta.y / 2)));

        // Re assign values as per device size.
        TRAVEL_DISTANCE_FOR_BALL = DEVICE_HEIGHT - topSpacing - bottomSpacing;
        UPWORD_SPEED_MULTIPLIER = UPWORD_SPEED_CONSTANT * (TRAVEL_DISTANCE_FOR_BALL / TRAVEL_DISTANCE_FOR_BALl_CONSTANT);
        DOWNWORD_SPEED_MULTIPLIER = DOWNWORD_SPEED_CONSTANT * (TRAVEL_DISTANCE_FOR_BALL / TRAVEL_DISTANCE_FOR_BALl_CONSTANT);

    }

    //This function will Instantiate Bouncing Pads and Obstacle.
    private void InitiatePadsAndObstacle() 
    {
        // Instantiate Right Pad
        Vector3 rightPadReferancePosition = new Vector3(-15f, 290.0f, 0f);
        rightPadReferance = Instantiate(rightPadPrefab, rightPadReferancePosition, Quaternion.identity) as GameObject;
        rightPadReferance.transform.SetParent(parentTransform, false);
        rightPadReferance.transform.SetAsLastSibling();
        rightPadReferance.tag = bouncingPadTag;
        // Instantiate Left Pad
        Vector3 leftPadReferancePosition = new Vector3(15f, 290.0f, 0f);
        leftPadReferance = Instantiate(leftPadPrefab, leftPadReferancePosition, Quaternion.identity) as GameObject;
        leftPadReferance.transform.SetParent(parentTransform, false);
        leftPadReferance.transform.SetAsLastSibling();
        leftPadReferance.tag = bouncingPadTag;

    }

    // Can be called from anywhere to Disable Bpuncing Pads and obstacles at any specific moment
    public void DisablePadsAndObstacles()
    {
        //obstacleReferance.SetActive(false);
        leftPadReferance.SetActive(false);
        rightPadReferance.SetActive(false);
        areBouncingPadsEnabled = false;
    }

    // Can be called from anywhere to Enable Bpuncing Pads and obstacles at any specific moment
    public void EnablePadsAndObstacles()
    {
        //obstacleReferance.SetActive(true);
        leftPadReferance.SetActive(true);
        rightPadReferance.SetActive(true);
        areBouncingPadsEnabled = true;
    }

    // This function will enable swipe script attached to playmode panel on specific condition
    private void EnableSwipeScriptofPanel()
    {

        if (PlayerPrefs.HasKey(KEY_USERNAME) == true)
        {
            userName = PlayerPrefs.GetString(KEY_USERNAME);
            userNameText.text = "Hi " + userName;
            playModePanel.GetComponent<Swipe>().enabled = true;
            userNameInputPanel.SetActive(false);
        }
        else
        {
            userNameInputPanel.SetActive(true);
        }
    }


    // This function is called to create instance of ball and place it properly
    public void CloneBall()
    {
        if (floorReferance.GetComponent<BoxCollider2D>().IsTouchingLayers((int)Layer.BallLayer) == false)
        {
            float ballYCordinate = -678f; 
            Vector3 ballReferancePosition = new Vector3(0f, ballYCordinate, 0f);
            ballReferance = Instantiate(ballPrefab, ballReferancePosition, Quaternion.identity) as GameObject;
            ballReferance.transform.SetParent(parentTransform, false);
            ballReferance.transform.SetAsLastSibling();
            ballReferance.tag = ballTag;
            if (WebServiceManager.sharedInstance.GetConfigParamFacesEnabled())
            {
                ballReferance.GetComponent<Image>().sprite = currentSprite;
                ballReferance.GetComponent<Outline>().enabled = true;
            }

            AddShadowToBall();
        }
        else
        {
            print("$$ABA-APPSTORE: Ball is already there : " + ballReferance);
        } 

    }


    //Internet connection check
    private void checkInterntConenction()
    {
        leaderBoardButton.interactable = Application.internetReachability != NetworkReachability.NotReachable;
        newsFeedButton.interactable = Application.internetReachability != NetworkReachability.NotReachable;
    }

    //This function adds shadow to ball.
    private void AddShadowToBall()
    {
        Vector3 shadowReferancePosition = new Vector3(0f, ballShadowOffset, 0f);
        GameObject shadow = Instantiate(shadowPrefab, shadowReferancePosition, Quaternion.identity) as GameObject;
        shadow.transform.SetParent(floorReferance.transform, false);
        shadowReferance = shadow;
    }

    // This function removes shadow from ball when ball is thrown.
    public void RemoveShadow(float ballThrowDirectionX)
    {
        Animator alphaAnimator = shadowReferance.GetComponent<Animator>();
        alphaAnimator.enabled = true;

        shadowReferance.GetComponent<RawImage>().CrossFadeAlpha(0.0f, 0.3f, false);

        if (ballThrowDirectionX <= 0.1f && ballThrowDirectionX >= -0.1f)
        {
            alphaAnimator.Play("UpThrowShadowAnimation", -1, 0.0f);
            Destroy(shadowReferance, 0.1f);
        }
        else if (ballThrowDirectionX < -0.1f)
        {
            alphaAnimator.Play("LeftThrowShadowAnimation", -1, 0.0f);
            Destroy(shadowReferance, 0.1f);

        }
        else
        {
            alphaAnimator.Play("RightThrowShadowAnimation", -1, 0.0f);
            Destroy(shadowReferance, 0.1f);

        }
    }

    // This function is called when game durations is over
    // Stop game happens sequencially in 3 steps
    public void StopGame()
    {
        print("$$ABA-APPSTORE: In stop game method");
        playModePanel.GetComponent<Swipe>().enabled = false;
        touchIgnorePointTop = Constants.DEVICE_HEIGHT - (Constants.DEVICE_HEIGHT * 0.12f);
        if (Application.internetReachability != NetworkReachability.NotReachable)
        {
            leaderBoardButton.interactable = false;
        }
        if (hoopReferance.GetComponent<HoopManager>() != null)
        {
            Destroy(hoopReferance.GetComponent<HoopManager>());
        }
        isThisFirstSwipeDone = false;
        durationOfRound = 20;
        setGameEndRewardedAd(false);
        ResetGameEndPopUpCount();

        StartCoroutine(StopGamePart1());
    }

    // Step 1 in Stop game :
    // 1. score management.
    // 2. Removing unnecessary/extra instances.
    // 3. Activate Home screen.
    // 3. showing one ball on game end.
    private IEnumerator StopGamePart1()
    {
        yield return new WaitForSeconds(0.75f);

        ScoreManager.sharedInstance.ManageScoresOnGameEnd();
        GameObject[] allBalls = GameObject.FindGameObjectsWithTag(ballTag);
        foreach (GameObject currentball in allBalls)
        {
            if (currentball.GetComponent<CircleCollider2D>().IsTouching(floorReferance.GetComponent<BoxCollider2D>()))
            {
                print("$$ABA-APPSTORE: One ball is here");
                Destroy(currentball);
            }
            else
            {
                if (currentball.transform.localScale.x > 1)
                {
                    print("$$ABA-APPSTORE: One big ball is there");
                    Destroy(currentball);
                }
            }
        }
        foreach (Transform child in floorReferance.transform)
        {
                 Destroy(child.gameObject);
        }

        CloneBall();

        HomeScreenActivation(true);
        StartCoroutine(StopGamePart2());

    }

    //Step 2
    // This function will geive call to Ads SDK to play game end Interstitial Ad.
    private IEnumerator StopGamePart2()
    {
        yield return new WaitForSeconds(0.25f);

        if (WebServiceManager.sharedInstance.GetConfigParamAdsEnabled()) {
        #if !UNITY_EDITOR
            //Play Auto cached ad and load rewarded Ad.
            Advertisment.sharedInstance.PlayGameEndAd();
            Advertisment.sharedInstance.LoadRewardedAd();
        #endif
        }

        StartCoroutine(StopGamePart3());
    }

    // Step 3
    // This function wil perform last step of Stop game sequence
    private IEnumerator StopGamePart3()
    {
        if (WebServiceManager.sharedInstance.GetConfigParamFacesEnabled())
        {
            // set image to ball
            int index = Random.Range(0, ballSprites.Length);
            if (currentSprite == ballSprites[index])
            {
                index = Random.Range(0, ballSprites.Length);
            }
            currentSprite = ballSprites[index];
            ballReferance.GetComponent<Image>().sprite = currentSprite;
        }
        yield return new WaitForSeconds(1.0f);
        playModePanel.GetComponent<Swipe>().enabled = true;
        if (Application.internetReachability != NetworkReachability.NotReachable)
        {
            leaderBoardButton.interactable = true;
        }
    }

    public void ShowGameEndPopup() {
        IncreaseGameEndPopUpCount();
        gameEndPopupOverlay.SetActive(true);
        GameEndPopup.sharedInstance.UpdatePopUpMessage();
    }

    public void CloseGameEndPopup() {
        gameEndPopupOverlay.SetActive(false);

        StopGame();
    }

    //Returne current ball instance
    public GameObject GetBallReferance()
    {
        return ballReferance;
    }

    // returne Y coordinate of Hoop. ie. center of Hoop
    public float GetBallTravelDistance()
    {
        return hoopY;
    }

    // returns Hoop top
    public float GetHoopTop()
    {
        return (hoopY
        + (hoopTransform.GetComponent<RectTransform>().sizeDelta.y / 2) * DEVICE_RESOLUTION_HEIGHT_FACTOR);
    }

    // returns bottom Y coordinate of Hoop
    public float GetHoopBottom()
    {
        return(hoopTransform.position.y
        -  (hoopTransform.GetComponent<RectTransform>().sizeDelta.y / 2) * DEVICE_RESOLUTION_HEIGHT_FACTOR);
    }

    //// returns position where ball should be placed on floor
    //public float GetInitialBallPosition()
    //{
    //    return ballPrefab.transform.position.y * DEVICE_RESOLUTION_HEIGHT_FACTOR;
    //}

    // returns size of ball
    public float GetBallSize()
    {
        return (ballReferance.GetComponent<RectTransform>().sizeDelta.y * DEVICE_RESOLUTION_HEIGHT_FACTOR) ;
    }

    // This function will return sibling index of 2nd last object in Game panel.
    // This is needed to show that ball is going behind hoop.
    public int GetSecondLastSiblingIndex()
    {
        return hoopBarReferance.transform.GetSiblingIndex();
    }

    // returns top of Hoop bar. Note Hoope bar and hoop are different. Hoop bar is red line in Hoop.
    public float GetHoopBarTop()
    {
        return DEVICE_HEIGHT + (hoopTransform.position.y * DEVICE_RESOLUTION_HEIGHT_FACTOR);
    }

    // returns referance of Hoop bar
    public GameObject GetHoopBarReference()
    {
        return hoopBarReferance;
    }

    // returns point at top above which swipe should be ignored
    public float GetTouchIgnorePointTop()
    {
        return touchIgnorePointTop;
    }

    // returns point at Bottom above which swipe should be ignored
    public float GetTouchIgnorePointBottom()
    {
        return touchIgnorePointBottom;
    }

    //Shows/Hides home screen and other panels accordingly
    private void HomeScreenActivation(bool shouldShowHomeScreen)
    {

        if (shouldShowHomeScreen)
        {
            hoopReferance.transform.GetChild(0).gameObject.SetActive(false);
            switch (scoreUI)
            {
            //show best score panel
                case HomeScreenScoreUI.BestScore:

                    lastScorePanel.SetActive(false);
                    launchScreenPanel.SetActive(false);
                    bestScorePanel.SetActive(true);

                    break;
            //show last score panel
                case HomeScreenScoreUI.LastScore:
				
                    lastScorePanel.SetActive(true);
                    launchScreenPanel.SetActive(false);
                    bestScorePanel.SetActive(false);

                    break;
            //show play button 
                case HomeScreenScoreUI.None:
				
                    lastScorePanel.SetActive(false);
                    launchScreenPanel.SetActive(true);
                    bestScorePanel.SetActive(false);

                    break;
                default:
                    print("$$ABA-APPSTORE: Wrong value of Score UI " + scoreUI.ToString());
                    break;
            }


        }
        else
        {	
            // Dont show home screen. Show Game play screen
            hoopReferance.transform.GetChild(0).gameObject.SetActive(true);
            ScoreManager.sharedInstance.ResetScore();
        }

        homeScreenPanel.SetActive(shouldShowHomeScreen); 
		 
    }

    // Disables swipe of
    private void DisableSwipe()
    {
        playModePanel.GetComponent<Swipe>().enabled = false;
    }

    private void EnableDisableNewsFeedButton(string state)
    {
        if(state == "1") {
            this.newsFeedButton.interactable = true;
        } else {
            this.newsFeedButton.interactable = false;
        }
    }
        // This function is called to start game
        public void StartGame()
    {
        if (Constants.sharedInstance.homeScreenPanel.activeSelf == true)
        {
            PlayGame();
            hoopReferance.AddComponent<HoopManager>();
            isThisFirstSwipeDone = true;
            CheckForNoScoreAttempt();
        }
        else
        {

            if (isThisFirstSwipeDone == false)
            {
                hoopReferance.AddComponent<HoopManager>();
                isThisFirstSwipeDone = true;
                CheckForNoScoreAttempt();
            }
        }

    }

    private void CheckForNoScoreAttempt() {
        gameAttemptCounter++;
        if (gameAttemptCounter == 4 || gameAttemptCounter == 6)
        {
            if (gameAttemptCounter == 6)
            {
                gameAttemptCounter = 0;
            }

            isThisNoScoreAttempt = true;
            hoopBoxColliderForNoScore.enabled = true;
        }
        else
        {
            isThisNoScoreAttempt = false;
            hoopBoxColliderForNoScore.enabled = false;
        }
    }
    //This function is called to play game
    public void PlayGame()
    {
        print("$$ABA-APPSTORE: **** KEY_ADDITIONAL_TIME ---" + PlayerPrefs.GetInt(Constants.KEY_ADDITIONAL_TIME).ToString());
        if (PlayerPrefs.GetInt(Constants.KEY_ADDITIONAL_TIME) == 1)
        {
            print("$$ABA-APPSTORE: **** durationOfRound ---" + durationOfRound.ToString());
            print("$$ABA-APPSTORE: **** additionalTime ---" + additionalTime.ToString());
            durationOfRound = durationOfRound + additionalTime;
            PlayerPrefs.SetInt(Constants.KEY_ADDITIONAL_TIME, 0);
            PlayerPrefs.SetInt(Constants.KEY_AD_VIEW_COUNT, 0);
        }
        ResetGameEndPopUpCount();
        holdTimerTillAdView = false;
        touchIgnorePointTop = DEVICE_HEIGHT;
        HomeScreenActivation(false);
        hoopReferance.GetComponentInChildren<Text>().text = durationOfRound.ToString() + ":00";
    }

    public void PauseGame()
    {
        holdTimerTillAdView = true;
        playModePanel.GetComponent<Swipe>().enabled = false;
        hoopReferance.GetComponentInChildren<Text>().text = "00:00";
    }

    public void ResumeGame()
    {
        hoopReferance.GetComponentInChildren<Text>().text = "05:00";
        //hoopReferance.transform.GetChild(0).gameObject.SetActive(true);
        StartCoroutine(ResumeWithDelay());
    }

    private IEnumerator ResumeWithDelay()
    {
        yield return new WaitForSeconds(0.0f);

        holdTimerTillAdView = false;
        playModePanel.GetComponent<Swipe>().enabled = true;
    }

    // Returns crossfade duration of ball
    public float GetBallCrossFadeDuration()
    {
        return 0.3f * DEVICE_RESOLUTION_HEIGHT_FACTOR;
    }

    // Returns device UDID
    public string GetDeviceUniqueIdentifier()
    {
		
        return SystemInfo.deviceUniqueIdentifier;
    }

    // Returns current date
    public string GetCurrentDate()
    {
        return System.DateTime.Now.ToString("MM/dd/yyyy");
    }

    // Sets user name on screen
    public void SetUserName(string userName)
    {
        this.userName = userName;
    }

    //returns username
    public string GetUserName()
    {
        return userName;
    }

    public bool AreBouncingPadsEnabled() 
    {
        return areBouncingPadsEnabled;
     }

    public float GetFloorHeight()
    {
        return (floorReferance.GetComponent<RectTransform>().sizeDelta.y * DEVICE_RESOLUTION_HEIGHT_FACTOR) ;    
    }

    public float GetGapBetweenFloorAndHoopBottom() {
        return (GetHoopBottom() - GetFloorHeight());
    }

    public float GetPointWhereNewBallShouldBeCreated() {
        return GetFloorHeight() + (GetGapBetweenFloorAndHoopBottom() / 2);
    }

    public float GetGapBetweenFloorAndHoopTop()
    {
        return (GetHoopTop() - GetFloorHeight());
    }

    public bool IsThisNoScoreAttempt() {
        return isThisNoScoreAttempt;
    }

    public void setGameEndRewardedAd(bool status)
    {
        isThisGameEndRewardedAd = status;
    }

    public bool IsGameEndRewardedAd()
    {
        return isThisGameEndRewardedAd;
    }

    public void IncreaseGameEndPopUpCount()
    {
        print("$$ABA-APPSTORE: gameEndPopUpCount prev - " + gameEndPopUpCount.ToString());
        gameEndPopUpCount++;
        print("$$ABA-APPSTORE: gameEndPopUpCount increased - " + gameEndPopUpCount.ToString());
    }

    public int getGameEndPopUpCount()
    {
        return gameEndPopUpCount;
    }

    private void ResetGameEndPopUpCount()
    {
        gameEndPopUpCount = 0;
    }

    public int CalculatePenalty()
    {
        return 5 * gameEndPopUpCount;
    }

    public void setGameEndAdAvailable(bool status)
    {
        isGameEndAdAvailable = status;
    }

    public bool IsGameEndAdAvailable()
    {
        return isGameEndAdAvailable;
    }

    public bool IsHoldTimerTillAdView()
    {
        return holdTimerTillAdView;
    }
}
