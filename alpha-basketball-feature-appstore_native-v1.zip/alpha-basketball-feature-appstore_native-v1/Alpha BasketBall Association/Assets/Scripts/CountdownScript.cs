﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class CountdownScript : MonoBehaviour {

	// Use this for initialization
	public int timeLeft = 3; //Seconds Overall
	public Text countdown;
	public GameObject countDownText;

	void Start () {
		
	}

//	void Awake()
//	{
//		timeLeft = 3;
//		StartCoroutine("LoseTime");
//		Time.timeScale = 1; //Just making sure that the timeScale is right
//
//	}

	void OnEnable()
	{
		Debug.Log("PrintOnEnable: script was enabled");
		timeLeft = 3;
		StartCoroutine("LoseTime");
		Time.timeScale = 1; //Just making sure that the timeScale is right
	}
	void Update () {

		if (timeLeft == 0) {
			countdown.text = ("GO!");
		}else{
			countdown.text = ("" + timeLeft.ToString()); //Showing the Score on the Canvas
		}
	}
	//Simple Coroutine
	IEnumerator LoseTime()
	{
		while (timeLeft > 0) {
			yield return new WaitForSeconds (1);
			timeLeft--; 
		} 
		Debug.Log ("Time Left" + timeLeft.ToString());
		yield return new WaitForSeconds (1);
		countDownText.SetActive (false);
		Constants.sharedInstance.ResumeGame();
	}

}

 