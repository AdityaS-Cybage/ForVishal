﻿
    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;
    using Firebase;
    using Firebase.Database;
    using Firebase.Unity.Editor;
    using System;
    using System.Threading.Tasks;

    // This singleton class handles all score related transactions with firebase.
    public class FirebaseManager : MonoBehaviour
    {
        private static FirebaseManager _instance;
        private bool contest_status = false;
        private FirebaseApp firebaseInstance;
        private FirebaseDatabase firebaseDatabaseInstance;
        private string deviceId;

        // Constants
        private static string SETTINGS_ROOT_ID = "usermanagement_settings";
        private static string SCORE_ROOT_ID = "usermanagement";
        private static string CONTEST_STATUS_KEY = "contest_status";
        private static string SCORE_KEY = "score";

        public static FirebaseManager sharedInstance { get { return _instance; } }

        private void Awake()
        {
            if (_instance != null && _instance != this)
            {
                Destroy(gameObject);
            }
            else
            {
                _instance = this;
            }
        }

        void Start()
        {
            IntializeFirebase();
            GetServerSettings();
            deviceId = Constants.sharedInstance.GetDeviceUniqueIdentifier();
        }

        private void IntializeFirebase()
        {
            firebaseInstance = FirebaseApp.DefaultInstance;
            firebaseInstance.SetEditorDatabaseUrl(WebServiceManager.sharedInstance.GetConfigParamDatabaseUrl());
            firebaseDatabaseInstance = FirebaseDatabase.DefaultInstance;
        }

        // returns firebase app instance
        public FirebaseApp GetFirebaseAppInstance()
        {
            return firebaseInstance;
        }

        // returns firebase db instance
        public FirebaseDatabase GetFirebaseDBInstance()
        {
            return firebaseDatabaseInstance;
        }
    		
        // this function will get settings like contest is running or not..etc
        private void GetServerSettings()
        {
            firebaseDatabaseInstance
                .GetReference(SETTINGS_ROOT_ID)
                .ValueChanged += HandleValueChanged;
        }

        // this is call back function if status of settings is changed..like contest is reset.
        void HandleValueChanged(object sender, ValueChangedEventArgs args)
        {
            if (args.DatabaseError != null)
            {
                Debug.LogError(args.DatabaseError.Message);
                return;
            }

            if (args.Snapshot != null && args.Snapshot.ChildrenCount > 0 && args.Snapshot.Child(CONTEST_STATUS_KEY) != null)
            {
                // cehck if contest status is boolean value or not.
                try
                {
                    contest_status = (bool)args.Snapshot.Child(CONTEST_STATUS_KEY).Value;
                }
                catch (Exception e)
                {
                    contest_status = false;
                    print("$$ABA-APPSTORE: Exception : " + e.Message);
                }
                print("$$ABA-APPSTORE: Contest Status : " + contest_status.ToString());
            }

            print("$$ABA-APPSTORE: Code reaches here : Contest Status : " + contest_status.ToString());
        }

        //This function will check whether score should be sent to server or not.
        public void CheckForSendingScore(int currentScore)
        {
            bool isFirstInstall = !PlayerPrefs.HasKey(Constants.KEY_FIRST_INSTALL);
            // if no contest is running no need to send score to server
            if (contest_status != true)
            {
                print("$$ABA-APPSTORE: No contest is running. Hence not sending the score to server.");
                return;
            }

            firebaseDatabaseInstance
                .GetReference(SCORE_ROOT_ID)
                .GetValueAsync().ContinueWith(task =>
                {
                    if (task.IsFaulted)
                    {
                        print("$$ABA-APPSTORE: CheckForSendingScore call is Faulty!");
                    }
                    else if (task.IsCompleted)
                    {
                        DataSnapshot snapshot = task.Result;
                        if (snapshot != null && snapshot.Value != null &&
                        snapshot.Child(deviceId) != null && snapshot.Child(deviceId).Value != null &&
                        snapshot.Child(deviceId).Child(SCORE_KEY) != null && snapshot.Child(deviceId).Child(SCORE_KEY).Value != null)
                        {
                            print("$$ABA-APPSTORE: Value of current score on server : " + snapshot.Child(deviceId).Child(SCORE_KEY).Value);
                            if (isFirstInstall)
                            {
                                SendScoreToServer(currentScore);
                            }
                            else if (int.Parse(snapshot.Child(deviceId).Child(SCORE_KEY).Value.ToString()) < currentScore)
                            {
                                SendScoreToServer(currentScore);
                            }
                            else
                            {
                                print("$$ABA-APPSTORE: Not a high score!");
                            }
                        }
                        else
                        {
                            SendScoreToServer(currentScore);
                        }
                    }
                    else
                    {
                        print("$$ABA-APPSTORE: Something else happened!" + task);
                    }
                });
        }

        // This function will send score to server
        private void SendScoreToServer(int currentScore)
        {
            string currentDate = Constants.sharedInstance.GetCurrentDate();
            string username = Constants.sharedInstance.GetUserName();

            UserScore userScore = new UserScore(deviceId, currentScore, currentDate, username);
            string json = JsonUtility.ToJson(userScore);

            Task task =  FirebaseDatabase.DefaultInstance.GetReference(SCORE_ROOT_ID).Child(deviceId).SetRawJsonValueAsync(json);
             PlayerPrefs.SetString(Constants.KEY_FIRST_INSTALL, "Score sent for 1st install");
            // below code is added for App store release
            //StartCoroutine(sendDataAfterDelay(json, task));
            tryThreeAttemptsOfSendingScore(json, task);
        }

        private IEnumerator sendDataAfterDelay(string json, Task task) {
            yield return new WaitForSeconds(1.0f);
             if (!task.IsCompleted) {
                print("$$ABA-APPSTORE: failed to send data to firebase");
                print("$$ABA-APPSTORE: " + task.Exception.ToString());
                // try to send data again after some time
                FirebaseDatabase.DefaultInstance.GetReference(SCORE_ROOT_ID).Child(deviceId).SetRawJsonValueAsync(json);
             }
        }

        private void tryThreeAttemptsOfSendingScore(string json, Task task)
        {

            if(!task.IsCompleted)
            {
                print("$$ABA-APPSTORE: failed to send data to firebase");
                print("$$ABA-APPSTORE: " + task.Exception.ToString());
                    int attempts = 0;
                    while (attempts < 3) 
                {
                     attempts++;
                     print("Making attempt number + " +  attempts + " to send data to server");
                    Task newTask = FirebaseDatabase.DefaultInstance.GetReference(SCORE_ROOT_ID).Child(deviceId).SetRawJsonValueAsync(json);

                    if (newTask.IsCompleted) 
                    {
                     print("Sending score so server successful");

                         break;
                    }
             }
            }
        }
        public bool GetContestStatus()
        {
            return contest_status;
        }

        // This is internal class, Object of this class is sent to server which include all info of user and score
        class UserScore
        {
            public string deviceID = "";
            public int score = 0;
            public string todate = "";
            public string username = "";

            public UserScore()
            {
            }

            public UserScore(string deviceID, int score, string todate, string username)
            {
                this.deviceID = deviceID;
                this.score = score;
                this.todate = todate;
                this.username = username;
            }
        }
    }
