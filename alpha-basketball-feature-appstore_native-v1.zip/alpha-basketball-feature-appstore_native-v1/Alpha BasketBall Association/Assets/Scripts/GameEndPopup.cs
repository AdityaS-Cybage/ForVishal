﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameEndPopup : MonoBehaviour
{
    private static GameEndPopup _instance;
    public static GameEndPopup sharedInstance { get { return _instance; } }

    private Animator anim;
  //  private Text popupMessage;

    private void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;
        }
    }


    void Start()
    {
        anim = gameObject.GetComponent<Animator>();
     //   popupMessage = GetComponentInChildren<Text>();
        //UpdatePopUpMessage();
        //anim.Play("Game_End_Popup", -1, 0.0f);
        //anim.enabled = true;
        //anim.StartPlayback();
        UpdatePopUpMessage();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void UpdatePopUpMessage()
    {
       
        GetComponentInChildren<Text>().text = "Get 5 more seconds in exchange for losing " +
            Constants.sharedInstance.CalculatePenalty().ToString() + " points.";
    }

    public void OnClickWatchAd()
    {
        print("$$ABA-APPSTORE: Watch Ad clicked");
        //play ad
        Constants.sharedInstance.setGameEndRewardedAd(true);
        Advertisment.sharedInstance.PlayRewardedAd();
        
		StartCoroutine(ClosePopupView());
        //Advertisment.sharedInstance.ManageExtendedPlaytime();

    }

    public void OnCLickSkip()
    {
        print("$$ABA-APPSTORE: Skip clicked");
        // Reverse animation play
        anim.SetFloat("Direction", -1);
        anim.Play("Game_End_Popup", -1, 0.0f);
        StartCoroutine(ClosePopup());
    }

	IEnumerator ClosePopupView()
	{
		yield return new WaitForSeconds (1.0f);
		Constants.sharedInstance.gameEndPopupOverlay.SetActive(false);
	}

    IEnumerator ClosePopup()
    {
        yield return new WaitForSeconds(0.22f);
        Constants.sharedInstance.CloseGameEndPopup();
    }
}
