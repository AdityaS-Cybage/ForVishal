﻿using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.UI;

// This class will handle all UI elements actions in Home screen
public class HomeScreenManager : MonoBehaviour
{
    
    // Use this for initialization
    #if UNITY_ANDROID

    // method for showing inApp webview in android, for showing leaderboard.
    public void CallWebView()
    {
        Debug.Log("Call WebView");
        AndroidJavaClass unity = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        AndroidJavaObject currentActivity = unity.GetStatic<AndroidJavaObject>("currentActivity");
        currentActivity.Call("OpenWebView", WebServiceManager.sharedInstance.GetConfigParamLeaderboardUrl());
    }

    void Start()
    {
        // to comment: if removing the add button
        // ResetAddButton();

        AndroidJavaClass unity = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        AndroidJavaObject currentActivity = unity.GetStatic<AndroidJavaObject>("currentActivity");
        currentActivity.Call("SetupCallBack", this.gameObject.name, "CallBack", "Calling back from Android");
    }
    #endif

    // code for plugin interaction with Unity.
    #if UNITY_IOS
    
	[DllImport("__Internal")]
	private static extern void _openURL(string url);
	[DllImport("__Internal")]
	private static extern void _setupCallBack(string gameObject, string methodName);
    [DllImport("__Internal")]
    private static extern void _fetchAndSaveNewsFeedData(string newsFeedurl);
    [DllImport("__Internal")]
    private static extern void _openNewsFeedViewController();

    // method for showing inApp webview in iOS, for showing leaderboard.
    public void CallWebView()
	{
		
    _openURL(WebServiceManager.sharedInstance.GetConfigParamLeaderboardUrl());

	}

	void Start()
	{
		if (Application.platform == RuntimePlatform.IPhonePlayer)
		{
			_setupCallBack(this.gameObject.name, "CallBack");
           if (Application.internetReachability != NetworkReachability.NotReachable) {
                _fetchAndSaveNewsFeedData(WebServiceManager.sharedInstance.GetConfigNewsFeedURL());
            }
            


		}
	}

	#endif

    // to start the gamePlay
    public void OnClickPlayButton()
    {
        Constants.sharedInstance.PlayGame();
    }

    // to show the ad via native plugin
    public void OnClickAdButton()
    {
    if (WebServiceManager.sharedInstance.GetConfigParamAdsEnabled()) {
        #if  !UNITY_EDITOR
            Advertisment.sharedInstance.PlayRewardedAd();
        #endif
        }

    }

    // This function will open leaderboard
    public void OnClickLeaderBoardButton()
    {
        #if (!UNITY_EDITOR)
		CallWebView();
        #else 
        Application.OpenURL(WebServiceManager.sharedInstance.GetConfigParamLeaderboardUrl());
        #endif

//        WebServiceManager.sharedInstance.AppendConfigParamsUrl();
//        WebServiceManager.sharedInstance.FetchConfigParams();
//        print("Response Called from the Homescreen manager !!!");
    }

    // This function will add +5 seconds each time.
    public void OnClickAdd5SecondsButton()
    {
        print("$$ABA-APPSTORE: Add 5 secs button clicked!");
        if (Constants.durationOfRound >= 20 && Constants.durationOfRound < 40)
        {
            Constants.durationOfRound = Constants.durationOfRound + 5;

            GameObject.Find("Add_5_sec").GetComponentInChildren<Text>().text = Constants.durationOfRound.ToString() + "";

//            foreach (Transform child in this.transform)
//            {
//                print("inside foreach :" + child.name);
//                if (child.tag == "Add5secsbutton")
//                    print("inside matched tag !!");
//                    child.gameObject.GetComponentInChildren<Text>().text = Constants.durationOfRound + "";
//            }
        }
        else if (Constants.durationOfRound == 40)
        {
            ResetAddButton();
        }
    }

    public void OnClickNewsfeedButton ()
    {
        print("$$ABA-APPSTORE: Unity button clicked");
        /*
#if UNITY_IOS
        print("$$ABA-APPSTORE: Inside Advertisement script giving call to _openNewsFeedViewController");
        _openNewsFeedViewController();
#elif UNITY_ANDROID
        print("$$ABA-APPSTORE: Inside Advertisement script for Android");
        string pluginName = "com.unityplugin.unityandroidplugin.MyPluginClass";
        AndroidJavaObject myPluginObject = new AndroidJavaObject(pluginName);
        myPluginObject.Call("launchNewsFeed", "sample_link_test123");
#endif
*/
    }

    private void ResetAddButton()
    {
        Constants.durationOfRound = 20;
        GameObject.Find("Add_5_sec").GetComponentInChildren<Text>().text = Constants.durationOfRound.ToString() + "";
    }

    void Update()
    {
        HandleBackButtonPressed();
    }

    // To Handle the Back button press in android
    void HandleBackButtonPressed()
    {
        if (Input.GetKeyUp(KeyCode.Escape))
        {
            if (Application.platform == RuntimePlatform.Android)
            {
                AndroidJavaObject activity = new AndroidJavaClass("com.unity3d.player.UnityPlayer")
                    .GetStatic<AndroidJavaObject>("currentActivity");
                activity.Call<bool>("moveTaskToBack", true);
                print("$$ABA-APPSTORE: Android back pressed!");
            }
            else
            {
                print("$$ABA-APPSTORE: Escape pressed!");
                Application.Quit();
            }
        }
    }
}
