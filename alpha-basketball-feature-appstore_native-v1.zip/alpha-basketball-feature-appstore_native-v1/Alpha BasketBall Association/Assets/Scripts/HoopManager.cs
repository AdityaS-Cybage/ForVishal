﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// This class handles Hoop animation and Hoop lifecycle during each game round.
public class HoopManager : MonoBehaviour
{
	private Animator animatorHoop;
	private Animator animatorHoopBar;
	private Text timerLabel;
	private float totalDuration = 0.0f;
	private float animationTrigger = 0.0f;
	private bool isRoundFinished = false;
	private bool shouldMoveHoop = true;
    private string[] hoopAnimationsCollection;
    private string hoopCurrentAnimation;
    private string[] hoopBarAnimationsCollection;
    private string hoopBarCurrentAnimation;
    


    void Start ()
	{	
		timerLabel = GetComponentInChildren<Text> ();
		timerLabel.text = Constants.durationOfRound.ToString ();
		animatorHoop = GetComponent<Animator> ();
       
        hoopAnimationsCollection = new string[] { Constants.HoopMovementFor05sec_option1, Constants.HoopMovementFor05sec_option3, Constants.HoopMovementFor05sec_option2 };
       
        animatorHoopBar = Constants.sharedInstance.GetHoopBarReference ().GetComponent<Animator> ();
		setAnimations ();
	}

	void setAnimations ()
	{
        StartCoroutine (SetupInitial20Sec(Constants.durationOfRound - 5.0f));

    }

    // Start hoop animation of 15 sec and after that setup other animatiosn based on conditions
    private IEnumerator SetupInitial20Sec(float receivedAnimationTrigger) 
    {
        animationTrigger = receivedAnimationTrigger;
        animatorHoop.Play(Constants.HoopMovementFor15secCurve, -1, 0.0f);
        animatorHoopBar.Play(Constants.HoopBarMovementFor15secCurve, -1, 0.0f);
        EnableAnimations();
        yield return new WaitForSeconds(19.99f);


        if (Constants.durationOfRound == 25)
        { // 20 + 5
            SetUp5Sec(5f);
            yield return new WaitForSeconds(4.99f);
        }
        else if (Constants.durationOfRound == 30)
        { // 20 + 10
            //SetUp10Sec(10f);
            SetUp10Sec();
            yield return new WaitForSeconds(9.99f);
            Constants.sharedInstance.DisablePadsAndObstacles();
        }
        else if (Constants.durationOfRound == 35)
        { // 20 + 10 + 5
           // SetUp10Sec(20f);
            SetUp10Sec();
            yield return new WaitForSeconds(9.99f);
            Constants.sharedInstance.DisablePadsAndObstacles();
            SetUp5Sec(5f);
            yield return new WaitForSeconds(4.99f);
        }
        else if (Constants.durationOfRound == 40)
        { // 20 + 5 + 10 + 5 
            SetUp5Sec(20f);
            yield return new WaitForSeconds(4.99f);
            //SetUp10Sec(15f);
            SetUp10Sec();
            yield return new WaitForSeconds(9.99f);
            Constants.sharedInstance.DisablePadsAndObstacles();
            SetUp5Sec(5f);
            yield return new WaitForSeconds(4.99f);
        }
        else if (Constants.durationOfRound == 45)
        { // 20 + 5 + 10 + 5 + 5 
            SetUp5Sec(25f);
            yield return new WaitForSeconds(4.99f);
            //SetUp10Sec(15f);
            SetUp10Sec();
            yield return new WaitForSeconds(9.99f);
            Constants.sharedInstance.DisablePadsAndObstacles();
            SetUp5Sec(10f);
            yield return new WaitForSeconds(4.99f);
            SetUp5Sec(5f);
            yield return new WaitForSeconds(4.99f);
        }

        else {
            print("$$ABA-APPSTORE: Undefined duration of round");
        }

    }

    private void SetUp5Sec(float receivedAnimationTrigger) 
    {
        int index = Random.Range(0, hoopAnimationsCollection.Length);
        hoopCurrentAnimation = hoopAnimationsCollection[index];

        hoopBarAnimationsCollection = new string[] { Constants.HoopMovementFor05sec_option1, Constants.HoopBarMovementFor05Sec_Option3, Constants.HoopBarMovementFor05Sec_Option2 };
        hoopBarCurrentAnimation = hoopBarAnimationsCollection[index];

        animationTrigger = receivedAnimationTrigger;
        shouldMoveHoop = true;
        animatorHoop.Play(hoopCurrentAnimation, -1, 0.0f);
        animatorHoopBar.Play(hoopBarCurrentAnimation, -1, 0.0f);
        EnableAnimations();
    }

    private void SetUp10Sec(float receivedAnimationTrigger)
    {
        int index = Random.Range(0, hoopAnimationsCollection.Length);
        hoopCurrentAnimation = Constants.HoopMovementFor10sec_New;
        hoopBarCurrentAnimation = Constants.HoopBarMovementFor10sec_New;

        animationTrigger = receivedAnimationTrigger;
        shouldMoveHoop = true;
        animatorHoop.Play(hoopCurrentAnimation, -1, 0.0f);
        animatorHoopBar.Play(hoopBarCurrentAnimation, -1, 0.0f);
        EnableAnimations();
    }


    private void SetUp10Sec()
    {
        shouldMoveHoop = false;
        Constants.sharedInstance.EnablePadsAndObstacles();
    }


    void EnableAnimations ()
	{
		animatorHoop.enabled = true;
		animatorHoopBar.enabled = true;
		animatorHoop.StartPlayback ();
		animatorHoopBar.StartPlayback ();
	}

	void Update ()
	{
		if (isRoundFinished == false) {
			updateTime ();
		}
	}

    private void updateTime()
    {
        if (!Constants.sharedInstance.IsHoldTimerTillAdView())
        {
            if (totalDuration <= 0 && isRoundFinished == false)
            {
                totalDuration = (float)Constants.durationOfRound;
            }

            // Calculate the remaining time
            totalDuration -= Time.deltaTime;

            if (totalDuration <= 0f)
            {
                CheckGameEnd();
            }
            if (totalDuration <= animationTrigger && shouldMoveHoop)
            {
                shouldMoveHoop = false;
                animatorHoop.StopPlayback();
                animatorHoopBar.StopPlayback();
            }

            // Update the timer
            timerLabel.text = (totalDuration.ToString("00.00")).Replace('.', ':');
        }
    }



    IEnumerator SingleFrameDelay ()
	{
        Advertisment.sharedInstance.LoadRewardedAd();
		//returning 0 will make it wait 1 frame
		yield return 0;
		animatorHoop.StartPlayback ();
		animatorHoopBar.StartPlayback ();
		animatorHoop.enabled = false;
		animatorHoopBar.enabled = false;
        //		print("Timer over - Animation stopped at : " + totalDuration);
        //Constants.sharedInstance.StopGame();
        //Constants.sharedInstance.IsGameEndAdAvailable()
    }

    private void CheckGameEnd()
    {
        if (Application.internetReachability != NetworkReachability.NotReachable
           && Constants.sharedInstance.IsGameEndAdAvailable())
        {
            totalDuration = 0;
            Constants.sharedInstance.PauseGame();
            Constants.sharedInstance.ShowGameEndPopup();
        }
        else
        {
            isRoundFinished = true;
            totalDuration = 0;
            StartCoroutine(SingleFrameDelay());
            Constants.sharedInstance.StopGame();
        }
    }
}
