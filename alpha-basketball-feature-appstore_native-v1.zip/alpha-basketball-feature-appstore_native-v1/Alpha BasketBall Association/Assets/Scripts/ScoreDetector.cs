﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This class is attached to score detector object.
public class ScoreDetector : MonoBehaviour
{

	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		
	}

	// This function is called when ball collides with score detector object
	void OnTriggerEnter2D (Collider2D other)
	{
        //print("Sibling index" + other.transform.GetSiblingIndex());
		if (other.gameObject.tag == Constants.ballTag && other.transform.GetSiblingIndex() < Constants.sharedInstance.GetSecondLastSiblingIndex()) {
            print("$$ABA-APPSTORE: Collision detected");
            if (Constants.sharedInstance.AreBouncingPadsEnabled()) {
                print("$$ABA-APPSTORE: Bouncing pads are enabled");
                if (other.gameObject.GetComponent<BallBehaviour>().DidCollideWithBouncingPads()) {
                    ScoreManager.sharedInstance.UpdateScore();
                }
                else {
                    print("$$ABA-APPSTORE: Ball did not collide with bouncing pads");
                }
            }
            else
            {
                print("$$ABA-APPSTORE: Bouncing pads are disabled");
                ScoreManager.sharedInstance.UpdateScore();
            }
			
		}
	}
}
