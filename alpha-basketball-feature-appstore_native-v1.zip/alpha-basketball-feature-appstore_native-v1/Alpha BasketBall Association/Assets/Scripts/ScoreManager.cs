﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// This singleton class will do score management work.
//Updating score, Storing score etc.
public class ScoreManager : MonoBehaviour
{
	private static ScoreManager _instance;

	public static ScoreManager sharedInstance { get { return _instance; } }

	private int currentscore = 0;
	public Text score;
	public Text lastScoreOfLastScorePanel;
	public Text bestScoreOfLastScorePanel;
	public Text bestScoreOfBestScorepanel;
	private bool shouldTrigger = true;

	private void Awake ()
	{
		if (_instance != null && _instance != this) {
			Destroy (gameObject);
		} else {
			_instance = this;
		}
	}

	void Start ()
	{
		ResetScore ();
	}

	public void UpdateScore ()
	{
		if (shouldTrigger == true) {
        
            currentscore++;
            if (currentscore > PlayerPrefs.GetInt (Constants.KEY_BEST_SCORE)) {
				score.color = new Color32(255,255,255,255); //new Color32 (255, 121, 16, 255);
			}  else {
                score.color = new Color32(118, 167, 248, 255);
            }
			score.text = currentscore.ToString();
		}
	}

	public void ResetScore ()
	{
		score.color = new Color32 (167, 167, 167, 255);
		score.gameObject.SetActive (true);
		currentscore = 0;
		shouldTrigger = true;
		score.text = currentscore.ToString();
	}

	public void ManageScoresOnGameEnd ()
	{
		score.gameObject.SetActive (false);
		PlayerPrefs.SetInt (Constants.KEY_LAST_SCORE, currentscore);

		if (PlayerPrefs.HasKey (Constants.KEY_BEST_SCORE) == true) {
			if (currentscore > PlayerPrefs.GetInt (Constants.KEY_BEST_SCORE)) {
				PlayerPrefs.SetInt (Constants.KEY_BEST_SCORE, currentscore);
				bestScoreOfBestScorepanel.text = currentscore.ToString ();
				// show best score UI
				Constants.scoreUI = HomeScreenScoreUI.BestScore;
			} else {	// current score is less than best score
				bestScoreOfLastScorePanel.text = PlayerPrefs.GetInt (Constants.KEY_BEST_SCORE).ToString ();
				lastScoreOfLastScorePanel.text = currentscore.ToString ();
				// show normal UI
				Constants.scoreUI = HomeScreenScoreUI.LastScore;
			}
		} else { 	// storing best score for the first time 
			PlayerPrefs.SetInt (Constants.KEY_BEST_SCORE, currentscore);
			bestScoreOfBestScorepanel.text = currentscore.ToString ();

			// Show best Score UI
			Constants.scoreUI = HomeScreenScoreUI.BestScore;
		}
        if (WebServiceManager.sharedInstance.GetConfigParamFirebaseEnabled()) {
            FirebaseManager.sharedInstance.CheckForSendingScore(currentscore);
        }
		
	}

    public void DecreaseScore(int scorePenalty)
    {
        if (currentscore - scorePenalty >= 0)
        {
            currentscore = currentscore - scorePenalty;
        }
        else
        {
            currentscore = 0;
        }

        if (currentscore > PlayerPrefs.GetInt(Constants.KEY_BEST_SCORE))
        {
            score.color = new Color32(255, 255, 255, 255); //new Color32(255, 121, 16, 255);
        }
        else
        {
            score.color = new Color32(118, 167, 248, 255);
        }
        score.text = currentscore.ToString();
    }
}