﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

// This class handles users swipe gesture and performs desired actions on swipe detection
public class Swipe : MonoBehaviour
{
	private bool shouldSwipeAgain = false;
	private Vector3 startPos;
	private  Vector3 SixtyDegRefForce =   new Vector3(341.6f,534.7f,0.0f);
	private  Vector3 OneTwentyDegRefForce =   new Vector3(-252.7f, 371.6f, 0.0f);

	void Start ()
	{

	}

	void Update ()
	{
		

		if (Application.isEditor) {
			UsingMouseTouchNew();
		} else {
			UsingTouchPhaseNew();
		}



	}
		

	private void UsingMouseTouchNew (){
	
		if (Input.GetMouseButtonDown (0)) {
			startPos = Input.mousePosition;

			if (startPos.y < Constants.sharedInstance.GetTouchIgnorePointBottom () || startPos.y > Constants.sharedInstance.GetTouchIgnorePointTop ()) {
				shouldSwipeAgain = true;
				return;
			}

			shouldSwipeAgain = false;

		} else if (Input.GetMouseButtonUp (0)) {
			
			BallThrowCall (Input.mousePosition, 50);

		}
	}

	private void UsingTouchPhaseNew () {

		if (Input.touchCount == 1) { // user is touching the screen with a single touch
			Touch touch = Input.GetTouch (0); // get the touch
			if (touch.phase == TouchPhase.Began) {

				startPos = new Vector3 (touch.position.x, touch.position.y, 0.0f);
                //print("$$ABA-APPSTORE: Start position Y : " + startPos.y);
                //print("$$ABA-APPSTORE: Touch ignore point bottom " + Constants.sharedInstance.GetTouchIgnorePointBottom());
                if (startPos.y < Constants.sharedInstance.GetTouchIgnorePointBottom () || startPos.y > Constants.sharedInstance.GetTouchIgnorePointTop ()) {
					shouldSwipeAgain = true;
					return;
				}

				shouldSwipeAgain = false;
				
			} else if (touch.phase == TouchPhase.Moved) {
			
			BallThrowCall (new Vector3(touch.position.x,touch.position.y,0.0f) , 150);

			} else if (touch.phase == TouchPhase.Ended) {
			
				BallThrowCall (touch.position, 50);

			}

		}

	}

	private void BallThrowCall(Vector3 endPos, float maxYSwipeDistance){
		

		Vector3 force = endPos - startPos;
        print("$$ABA-APPSTORE: Vector force " + force.ToString());
		float angle = Vector3.Angle (Vector3.right, force);


		if (Constants.sharedInstance.GetBallReferance () != null && shouldSwipeAgain == false && force.y > maxYSwipeDistance) {

			shouldSwipeAgain = true;
            float minAngle = 0;
            float maxAngle = 0;
            float minRangeVal = 0;
            float maxRangeVal = 0;
            float multiplyingFactor = 0;

           // if (Constants.sharedInstance.AreBouncingPadsEnabled()) {
          //        minAngle = 40;
           //       maxAngle = 160;
           //       minRangeVal = 80;
           //       maxRangeVal = 100;
           //       multiplyingFactor = 40;
        
           // }
           // else {
             //   print("inside else loop");
                minAngle = 50;
                maxAngle = 130;
                minRangeVal = 65;
                maxRangeVal = 115;
                multiplyingFactor = 35;
          //  }

            if (angle >= 0 && angle <= minAngle) {
				angle = minAngle;

			}
			if (angle >= maxAngle) {
				angle = maxAngle;
			}

			force.y = GetForceConstant (angle, minRangeVal,maxRangeVal, multiplyingFactor);
            //print("force.y "+ force.y);
			force /= 0.3f; 
			Constants.sharedInstance.StartGame ();
            print("$$ABA-APPSTORE: force final " + force.ToString());
            // if (Constants.sharedInstance.GetBallReferance().GetComponent<BallBehaviour>().isActiveAndEnabled == true) {
            Constants.sharedInstance.GetBallReferance().GetComponent<BallBehaviour>().ThrowWithForceNew(force);
           // } 
            //StartCoroutine(CloneBall());
        }

	}


		public float GetForceConstant (float angle, float minRangeVal, float maxRangeVal, float multiplyingFactor) {



        float forceFor90deg = 720 * Constants.DEVICE_RESOLUTION_HEIGHT_FACTOR;
            if (Constants.DEVICE_RESOLUTION_HEIGHT_FACTOR <= 1) {
            return forceFor90deg; 
            }		
			if (angle >= minRangeVal && angle <= maxRangeVal) {
				return forceFor90deg;
			} else if (angle > maxRangeVal) {
			float multiplier = ((180 - angle) + (multiplyingFactor * Constants.DEVICE_RESOLUTION_HEIGHT_FACTOR)) / 100;
				return forceFor90deg * multiplier;
			} else  {
			float multiplier = (angle + (multiplyingFactor * Constants.DEVICE_RESOLUTION_HEIGHT_FACTOR)) / 100;

				return forceFor90deg * multiplier;
			}
		}

    }
