﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//This class handles user action on Username input panel. 
public class UserNameInputManager : MonoBehaviour
{

	public InputField userName;

	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		
	}

	//This function is called when usser clicks on Done button in Usernae popup.
	public void OnClickDoneButton ()
	{
		print ("Button clicked");
		StartCoroutine (Login ());


	}

	IEnumerator Login (){
		
		if (userName.text.Length != 0) {

            ABALoaderManager.sharedInstance.showLoader();
			//WebServiceManager.sharedInstance.checkUserValid(userName.text);

			string userData = null;
			bool wait2 = true;
			WebServiceManager.sharedInstance.StartRoutineCheckLoginCorrect (userName.text,(callback) =>{
				userData = callback;
				wait2 = false;
			});

			while (wait2) {
				yield return null;
			}
				
			print (Constants.sharedInstance.Login);
			print (userData);

			if (Constants.sharedInstance.Login) {
				userValid ();
			} else {
				userInValid (userData);
			}


		}
	}

	public void userValid(){
        ABALoaderManager.sharedInstance.HideLoader ();
		print ("User Valid Received");
        PlayerPrefs.SetString(Constants.KEY_USERNAME, userName.text);
        PlayerPrefs.SetInt(Constants.KEY_AD_VIEW_COUNT, 0);
        PlayerPrefs.SetString (Constants.KEY_USERNAME, userName.text);
		Constants.sharedInstance.SetUserName (userName.text);
		Constants.sharedInstance.playModePanel.GetComponent<Swipe> ().enabled = true;
		Constants.sharedInstance.userNameInputPanel.SetActive (false);
		Constants.sharedInstance.userNameText.text = "Hi " + userName.text;
		// show banner ad view
		Advertisment.sharedInstance.AddBannerAdView();
	}

	public void userInValid(string message){
        ABALoaderManager.sharedInstance.HideLoader ();
		if (message != null) {
            ABAAlertManager.showAlertConnection();
		} else {
            ABAAlertManager.showAlertUser ();
		}

		//Constants.sharedInstance.userNameInputPanel.SetActive (true);
		userName.text = "";
		print ("User InValid Received"+ message);
	}
}
