using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class WebServiceManager : MonoBehaviour
{
    private static WebServiceManager _instance;
    //production: https://us-central1-alpha-basketball.cloudfunctions.net/configurationsRecord
    //staging: https://us-central1-unity-demo-9c4bf.cloudfunctions.net/configurationsRecord

    // Prod Env:

    private string APIEndpoint = "https://us-central1-alpha-basketball.cloudfunctions.net";
    private string GetConfigParamsUrl = "https://us-central1-alpha-basketball.cloudfunctions.net/configurationsRecord";
    private string NewsFeedURL = "";//"https://us-central1-alpha-basketball.cloudfunctions.net/newsRecords";
    private string DatabaseUrl = "https://alpha-basketball.firebaseio.com/";
    private string LeaderboardUrl = "https://alpha-basketball.firebaseapp.com";
	private string GetUserValidURL = "https://us-central1-alpha-basketball.cloudfunctions.net/usersStatus?uname=";

    // Staging Env:

//    private string APIEndpoint = "https://us-central1-unity-demo-9c4bf.cloudfunctions.net";
//    private string GetConfigParamsUrl = "https://us-central1-unity-demo-9c4bf.cloudfunctions.net/configurationsRecord";
//    private string NewsFeedURL = "https://us-central1-unity-demo-9c4bf.cloudfunctions.net/newsRecords";
//    private string DatabaseUrl = "https://unity-demo-9c4bf.firebaseio.com/";
//    private string LeaderboardUrl = "https://unity-demo-9c4bf.firebaseapp.com";
//    private string GetUserValidURL = "https://us-central1-unity-demo-9c4bf.cloudfunctions.net/usersStatus?uname=";

    private bool resultStatus;
    private ConfigParams currentConfigParams;

    // Constants
    private string TestId = "TestId";
    private string AppVersion = "1.0";
    private string BannerAdSize = "banner";
    private string InFeedAdType = "infeed";
    private enum IntegrationTypeEnum { unity, native }
    private string sdkIntegrationType = (IntegrationTypeEnum.native).ToString();

    private string app_id;
    private string autoCachePlacementReferenceID;
    private string rewardedPlacementReferenceID;
    private string bannerAdPlacementID;
    private string inFeedAdPlacementID;
    private float padForce;
    private float DEVICE_HEIGHT = Screen.height;
    private float DEVICE_WIDTH = Screen.width;
    private float maxGraviyScaleValueOffline = 0.0f;

    public static WebServiceManager sharedInstance { get { return _instance; } }

    private void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;
        }
    }
    // Use this for initialization
    void Start()
    {
        //	PlayerPrefs.DeleteAll ();
        ABALoaderManager.sharedInstance.showLoader();
        AssignDefaultValues();
        AppendConfigParamsUrl();
        FetchConfigParams();
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void AssignDefaultValues()
    {
#if UNITY_IOS
        app_id = "5d013b549a86cb541f181a4d";
        autoCachePlacementReferenceID = "DEFAULT-972442";
        rewardedPlacementReferenceID = "REWARDED-3967807";
        bannerAdPlacementID = "BANNER-1422635";
        inFeedAdPlacementID = "MREC-1099459";
#elif UNITY_ANDROID
        app_id = "5d009cf4169e9a001761d3b2";
        autoCachePlacementReferenceID = "DEFAULT-1895613";
        rewardedPlacementReferenceID = "LOCAL_REWARDED-2684470";
        bannerAdPlacementID = "BANNER1-9011454";
        inFeedAdPlacementID = "FLEXFEED-2744806";
#elif UNITY_EDITOR || UNITY_WSA_10_0
        app_id = "5d0b2d84c318ea0011fca0fe";
        autoCachePlacementReferenceID = "DEFAULT-9751646";
        rewardedPlacementReferenceID = "WIN_REWARDED_UNITY-7983270";
#endif
    }

    public void AppendConfigParamsUrl()
    {
        string deviceType = "";
        #if UNITY_IOS
        deviceType = "ios";
#endif
#if UNITY_ANDROID
        deviceType = "android";
#endif
#if UNITY_WSA_10_0 ///*UNITY_EDITOR ||*/
        deviceType = "windows";
#endif

        string appVersion = Application.version;
        string resolution = Screen.width.ToString() + "X" + Screen.height.ToString();
        GetConfigParamsUrl += "?devicetype=" + deviceType + "&sdktype=" + sdkIntegrationType + "&appversion=" + appVersion + "&resolution=" + resolution;

        print("$$ABA-APPSTORE: CS_Response_GetConfigParamsFromServer URL : " + GetConfigParamsUrl);
    }

    public void FetchConfigParams()
    {
        if (Application.internetReachability != NetworkReachability.NotReachable)
        {
            StartCoroutine(GetConfigParamsFromServer());
        }
        else
        {
            InitializeConstantsScript();
        }
    }
		
	public void StartRoutineCheckLoginCorrect (string username, Action<string> callback)
	{
		if (Application.internetReachability != NetworkReachability.NotReachable)
		{
		 StartCoroutine (Login (username, callback));
		}
		else
		{
			print ("No Internet");
			callback ("no internet");
		}
	}

	private IEnumerator Login (string username, Action<string> callback)
	{

//		bool isUserValid;
		print ("User Name Called");

		using (WWW www = new WWW (GetUserValidURL + username)) {
			yield return www;
			print ("GetUserValidURL ParamsUrl : " + www.text);

			if (www.error != null) {
				print ("GetUserValidURLError occoured " + www.error);
				Constants.sharedInstance.Login = false;
				callback (www.error);

			} else {
				if (www.text.Contains ("<html>")) {
					print ("CS_Response_There was HTML in response");
					callback ("html response");

				} else {

					UserValid response = JsonUtility.FromJson<UserValid> (www.text);

					try {
						bool isUserValid = (bool)response.status;


						if (isUserValid) {
							print ("UserValid");
							Constants.sharedInstance.Login = true;
							callback ("");
						} else {
							print ("UserInValid");
							Constants.sharedInstance.Login = false;
							callback (null);
						}


					} catch (Exception e) {
						Constants.sharedInstance.Login = false;
						callback (e.Message);
						print ("Exception : " + e.Message);
					}
				}

			}

		}
	}

    private void InitializeConstantsScript()
    {
        this.GetComponent<Constants>().enabled = true;
        ABALoaderManager.sharedInstance.HideLoader();
    }

    private IEnumerator GetConfigParamsFromServer()
    {
        print("$$ABA-APPSTORE: CS_Response_GetConfigParamsFromServer Called");

        using (WWW www = new WWW(GetConfigParamsUrl))
        {
            yield return www;
            print("$$ABA-APPSTORE: CS_Response_Response Config ParamsUrl : " + www.text);
           
            if (www.error != null) {
                print("$$ABA-APPSTORE: CS_Response_Response Error occoured " + www.error);
                InitializeConstantsScript();
            } else {
                if (www.text.Contains("<html>")) {
                    print("$$ABA-APPSTORE: CS_Response_There was HTML in response");
                    InitializeConstantsScript();
                }else {
                    currentConfigParams = JsonUtility.FromJson<ConfigParams>(www.text);
                    try
                    {
                        resultStatus = (bool)currentConfigParams.status;
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.status : " + currentConfigParams.status.ToString());
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.appId : " + currentConfigParams.appId);
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.testId : " + currentConfigParams.testId);
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.interstitialAdId : " + currentConfigParams.interstitialAdId);
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.rewardAdId : " + currentConfigParams.rewardAdId);
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.database : " + currentConfigParams.database);
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.leaderboard : " + currentConfigParams.leaderboard);
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.appVersion : " + currentConfigParams.appVersion);
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.facesEnabled : " + currentConfigParams.facesEnabled.ToString());
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.firebaseEnabled : " + currentConfigParams.firebaseEnabled.ToString());
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.adsEnabled : " + currentConfigParams.adsEnabled.ToString());
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.bannerAdId : " + currentConfigParams.bannerAdId);
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.inFeedAdId : " + currentConfigParams.inFeedAdId);
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.gravity : " + currentConfigParams.gravity.ToString());
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.padForce : " + currentConfigParams.padForce.ToString());
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.bannerAdSize : " + currentConfigParams.bannerAdSize);
                        print("$$ABA-APPSTORE: CS_Response_currentConfigParams.inFeedAdType : " + currentConfigParams.inFeedAdType);

                        InitializeConstantsScript();
                    }
                    catch (Exception e)
                    {
                        resultStatus = false;
                        print("$$ABA-APPSTORE: Exception : " + e.Message);
                        InitializeConstantsScript();
                    }
                }

            }

        }
    }



    private float ManualGravityCalculations()
    {
        print("$$ABA-APPSTORE: Inside Manual gravity calculations");
        float DEVICE_RESOLUTION_HEIGHT_FACTOR = DEVICE_HEIGHT / 1920;
        float DEVICE_RESOLUTION_WIDTH_FACTOR = DEVICE_WIDTH / 1080;

        if (DEVICE_RESOLUTION_HEIGHT_FACTOR >= 1){
            if (DEVICE_RESOLUTION_HEIGHT_FACTOR >= (1.33)){
                if (DEVICE_RESOLUTION_WIDTH_FACTOR >= (1.33))
                {//1440x2560, 1440x2880, 1440x2960, 1440x3120 ////960-(1440-1080)x(1.333-1) 
                    if (DEVICE_RESOLUTION_WIDTH_FACTOR >= 2){
                        return (DEVICE_WIDTH / 4.0f);
                    } else {
                        return (960 - ((DEVICE_WIDTH - 1080) * (DEVICE_RESOLUTION_WIDTH_FACTOR - 1)));
                    }
                } else{ //iPhoneXSMax 1242x2688   //960+(1242-1080)x(1.15-1)
                    return (960 + ((DEVICE_WIDTH - 1080) * (DEVICE_RESOLUTION_WIDTH_FACTOR - 1)));
                }
            } else {
                if (Constants.DEVICE_RESOLUTION_WIDTH_FACTOR > 1) {//1125x2436 
                    return ((960 * DEVICE_RESOLUTION_HEIGHT_FACTOR) - ((DEVICE_WIDTH - 1080) / 2));
                } else { //1080x2280,1080x2160,1080x2340 Android devices
                    if (Mathf.Approximately(DEVICE_HEIGHT, 1920)) {
                         return 960;
                    } else if (DEVICE_HEIGHT > 1920 && DEVICE_HEIGHT < 2019) {
                        return 1100;
                    } else if (DEVICE_HEIGHT > 2020 && DEVICE_HEIGHT < 2119) {
                        return 1200;
                    } else if (DEVICE_HEIGHT > 2120 && DEVICE_HEIGHT < 2350) {
                        return 1300;
                    } else {
                        print("$$ABA-APPSTORE: Device width is just 1080 but height is more than 2350");
                        return 1400;
                    }
                }

            }
        } else { //devices lower than 1080x1920
            if (DEVICE_RESOLUTION_HEIGHT_FACTOR.ToString("F2") == DEVICE_RESOLUTION_WIDTH_FACTOR.ToString("F2")) { 
                // iphone 6,7,8 and other low resolution android devices
                return (DEVICE_RESOLUTION_HEIGHT_FACTOR * 960);
            } else {
                if (DEVICE_HEIGHT > 1350 && DEVICE_HEIGHT < 1535) { // Redmi Y2 // (1920 x 0.7 to 0.8)
                    return 900;
                } else if (DEVICE_HEIGHT > 1536 && DEVICE_HEIGHT < 1727) { // not sure about theses devices //(1920 x 0.8 to 0.9)
                    return 1250;
                } else {  // iphone Xr
                    return 1600;
                }
            }
        }
    }


    private bool OfflineDeviceCalculation(string resolution) {
        print("$$ABA-APPSTORE: Inside offline gravity Calculation");
        bool isresolutionMatched = false; 
        switch (resolution.ToUpper())
        {
            case "720X1280":
                maxGraviyScaleValueOffline = 640;
                isresolutionMatched = true;
                break;
            case "750X1334":
                maxGraviyScaleValueOffline = 667;
                isresolutionMatched = true;
                break;
            case "828X1792":
                maxGraviyScaleValueOffline = 1600;
                isresolutionMatched = true;
                break;
            case "768X1280":
                maxGraviyScaleValueOffline = 600;
                isresolutionMatched = true;
                break;
            case "800X1280":
                maxGraviyScaleValueOffline = 560;
                isresolutionMatched = true;
                break;
            case "736X1280":
                maxGraviyScaleValueOffline = 620;
                isresolutionMatched = true;
                break;
            case "752X1280":
                maxGraviyScaleValueOffline = 600;
                isresolutionMatched = true;
                break;
            case "1080X1920":
                maxGraviyScaleValueOffline = 960;
                isresolutionMatched = true;
                break;
            case "1080X2160":
                maxGraviyScaleValueOffline = 1300;
                isresolutionMatched = true;
                break;
            case "1080X2220":
                maxGraviyScaleValueOffline = 1300;
                isresolutionMatched = true;
                break;
            case "1080X2240":
                maxGraviyScaleValueOffline = 1300;
                isresolutionMatched = true;
                break;
            case "1080X2244":
                maxGraviyScaleValueOffline = 1300;
                isresolutionMatched = true;
                break;
            case "1080X2340":
                maxGraviyScaleValueOffline = 1300;
                isresolutionMatched = true;
                break;
            case "1080X1800":
                maxGraviyScaleValueOffline = 830;
                isresolutionMatched = true;
                break;
            case "1080X2280":
                maxGraviyScaleValueOffline = 1300;
                isresolutionMatched = true;
                break;
            case "1080X2400":
                maxGraviyScaleValueOffline = 1200;
                isresolutionMatched = true;
                break;
            case "1080X2316":
                maxGraviyScaleValueOffline = 1300;
                isresolutionMatched = true;
                break;
            case "1080X2040":
                maxGraviyScaleValueOffline = 1200;
                isresolutionMatched = true;
                break;
            case "1080X2246":
                maxGraviyScaleValueOffline = 1300;
                isresolutionMatched = true;
                break;
            case "2160X3840":
                maxGraviyScaleValueOffline = 540;
                isresolutionMatched = true;
                break;
            case "1125X2436":
                maxGraviyScaleValueOffline = 1200;
                isresolutionMatched = true;
                break;
            case "1242X2688":
                maxGraviyScaleValueOffline = 985;
                isresolutionMatched = true;
                break;
            case "1312X2560":
                maxGraviyScaleValueOffline = 930;
                isresolutionMatched = true;
                break;
            case "1600X2560":
                maxGraviyScaleValueOffline = 760;
                isresolutionMatched = true;
                break;
            case "1440X2992":
                maxGraviyScaleValueOffline = 835;
                isresolutionMatched = true;
                break;
            case "1644X3840":
                maxGraviyScaleValueOffline = 720;
                isresolutionMatched = true;
                break;
            case "1440X2560":
                maxGraviyScaleValueOffline = 840;
                isresolutionMatched = true;
                break;
            case "1440X2880":
                maxGraviyScaleValueOffline = 820;
                isresolutionMatched = true;
                break;
            case "1440X2960":
                maxGraviyScaleValueOffline = 820;
                isresolutionMatched = true;
                break;
            case "1440X3120":
                maxGraviyScaleValueOffline = 835;
                isresolutionMatched = true;
                break;
            case "1440X3040":
                maxGraviyScaleValueOffline = 820;
                isresolutionMatched = true;
                break;
            case "640X1136":
                maxGraviyScaleValueOffline = 568;
                isresolutionMatched = true;
                break;
            case "1242X2208":
                maxGraviyScaleValueOffline = 1023;
                isresolutionMatched = true;
                break;
            case "1170X2532": //iphone 12 and 12 pro
                 maxGraviyScaleValueOffline = 1050;
                isresolutionMatched = true;
                break;
            case "1284X2778": //iphone 12 pro max
                 maxGraviyScaleValueOffline = 900;
                isresolutionMatched = true;
                break;
            default:
                maxGraviyScaleValueOffline = 0.0f;
                isresolutionMatched = false;
                break;

        }
        return isresolutionMatched;
    }

    public string GetConfigParamAppId()
    {
        if (resultStatus && currentConfigParams.appId != null && currentConfigParams.appId != "")
        {
            return currentConfigParams.appId;
        }
            return app_id;
    }

    public string GetConfigParamTestId()
    {
        if (resultStatus && currentConfigParams.testId != null && currentConfigParams.testId != "")
        {
            return currentConfigParams.testId;
        }
            return TestId;
    }

    public string GetConfigParamRewardedAdId()
    {
        if (resultStatus && currentConfigParams.rewardAdId != null && currentConfigParams.rewardAdId != "")
        {
            return currentConfigParams.rewardAdId;
        }
            return rewardedPlacementReferenceID;
    }

    public string GetConfigParamBannerAdId()
    {
        if (resultStatus && currentConfigParams.bannerAdId != null && currentConfigParams.bannerAdId != "")
        {
            return currentConfigParams.bannerAdId;
        }
        return bannerAdPlacementID;
    }

    public string GetConfigParamInFeedAdId()
    {
        if (resultStatus && currentConfigParams.inFeedAdId != null && currentConfigParams.inFeedAdId != "")
        {
            return "" ;//currentConfigParams.inFeedAdId;
        }
        return ""; //inFeedAdPlacementID;
    }

    public string GetConfigParamInterstitialAdId()
    {
        if (resultStatus && currentConfigParams.interstitialAdId != null && currentConfigParams.interstitialAdId != "")
        {
            return currentConfigParams.interstitialAdId;
        }
            return autoCachePlacementReferenceID;
    }

    public string GetConfigParamDatabaseUrl()
    {
        if (resultStatus && currentConfigParams.database != null && currentConfigParams.database != "")
        {
            return currentConfigParams.database;
        }
            return DatabaseUrl;
    }

    public string GetConfigParamLeaderboardUrl()
    {
        if (resultStatus && currentConfigParams.leaderboard != null && currentConfigParams.leaderboard != "")
        {
            return currentConfigParams.leaderboard;
        }
            return LeaderboardUrl;
    }

    public string GetConfigParamAppVersion()
    {
        if (resultStatus && currentConfigParams.appVersion != null && currentConfigParams.appVersion != "")
        {
            return currentConfigParams.appVersion;
        }
            return AppVersion;
    }

    public bool GetConfigParamFacesEnabled()
    {
        return false;
        /*
        return (resultStatus)
                ? currentConfigParams.facesEnabled
                : true;
                */               
    }

    public bool GetConfigParamFirebaseEnabled()
    {
        return true;
        /*
        return (resultStatus)
                ? currentConfigParams.firebaseEnabled
                : true;
                */               
    }

    public bool GetConfigParamAdsEnabled()
    {
        return true;
        /*
        return (resultStatus)
                ? currentConfigParams.adsEnabled
                : true;
                */               
    }

    public string GetConfigNewsFeedURL()
    {
        return NewsFeedURL;
    }

    public bool IsIntegrationTypeNative() {
        return (sdkIntegrationType == IntegrationTypeEnum.native.ToString()) ? true : false;
    }

    public float GetConfigParamGravityValue() {
        if (resultStatus && currentConfigParams.gravity > 0) {
            print("$$ABA-APPSTORE: Returned from configuration settings calculations");
            return currentConfigParams.gravity;
        } else {
            string deviceResolution = Screen.width.ToString() + "X" + Screen.height.ToString();
             ;
            if (OfflineDeviceCalculation(deviceResolution) == false)
            {
                print("$$ABA-APPSTORE: Returned from manual calculations");
                return ManualGravityCalculations();
            } else {
                print("$$ABA-APPSTORE: Returned from offline calculations");
                return maxGraviyScaleValueOffline;
            }
        }
    }

    public float GetConfigParamPadForce() {
        if (resultStatus && currentConfigParams.padForce >= 0) {
            return currentConfigParams.padForce;
        }  
            return (DEVICE_HEIGHT / 1920) > 1 ? 35000 : 0;
    }

    public string GetConfigParamBannerAdSize()
    {
        if (resultStatus && currentConfigParams.bannerAdSize != null && currentConfigParams.bannerAdSize != "")
        {
            return currentConfigParams.bannerAdSize;
        }
        return BannerAdSize;
    }

    public string GetConfigParamInFeedAdType()
    {
        if (resultStatus && currentConfigParams.inFeedAdType != null && currentConfigParams.inFeedAdType != "")
        {
            return "" ; //currentConfigParams.inFeedAdType;
        }
        return ""; //InFeedAdType;
    }

	[Serializable]
	private class UserValid
	{
		public bool status;
	}
		
    [Serializable]
    private class ConfigParams
    {
        public string appId;
        public string testId;
        public string rewardAdId;
        public string interstitialAdId;
        public string database;
        public string leaderboard;
        public string appVersion;
        public bool status;
        public bool facesEnabled;
        public bool firebaseEnabled;
        public bool adsEnabled;
        public int gravity;
        public int padForce;
        public string bannerAdId;
        public string inFeedAdId;
        public string bannerAdSize;
        public string inFeedAdType;

        public ConfigParams()
        {
        }


        public ConfigParams(string appId,
                            string testId,
                            string rewardAdId,
                            string interstitialAdId,
                            string database,
                            string leaderboard,
                            string appVersion,
                            bool status,
                            bool facesEnabled,
                            bool firebaseEnabled,
                            bool adsEnabled, 
                            int gravity,
                            int padForce,
                            string bannerAdId,
                            string inFeedAdId,
                            string bannerAdSize,
                            string inFeedAdType)

    
        {
            this.appId = appId;
            this.testId = testId;
            this.rewardAdId = rewardAdId;
            this.interstitialAdId = interstitialAdId;
            this.database = database;
            this.leaderboard = leaderboard;
            this.appVersion = appVersion;
            this.status = status;
            this.facesEnabled = facesEnabled;
            this.firebaseEnabled = firebaseEnabled;
            this.adsEnabled = adsEnabled;
            this.inFeedAdId = inFeedAdId;
            this.bannerAdId = bannerAdId;
            this.gravity = gravity;
            this.padForce = padForce;
            this.bannerAdSize = bannerAdSize;
            this.inFeedAdType = inFeedAdType;
        }
    }
}